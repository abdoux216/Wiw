-- ============================================================
-- 🗄️ ديجي كارد - DIJICARD
-- كود إنشاء قاعدة البيانات (مرتب صح)
-- شغّله كاملاً في: Supabase → SQL Editor → Run
-- ============================================================

-- تفعيل UUID
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ╔══════════════════════════════════════════╗
-- ║  الخطوة 1: إنشاء كل الجداول            ║
-- ╚══════════════════════════════════════════╝

CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT NOT NULL,
  phone TEXT NOT NULL DEFAULT '',
  role TEXT NOT NULL DEFAULT 'customer' CHECK (role IN ('customer', 'admin', 'moderator')),
  permissions JSONB DEFAULT '[]',
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS products (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  description TEXT DEFAULT '',
  category TEXT NOT NULL DEFAULT 'cards',
  original_price NUMERIC(10,2) NOT NULL,
  sell_price NUMERIC(10,2) NOT NULL,
  icon TEXT DEFAULT '💳',
  is_active BOOLEAN DEFAULT true,
  stock INTEGER DEFAULT 100,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS orders (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id),
  product_id UUID REFERENCES products(id),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'delivered', 'rejected')),
  delivery_name TEXT NOT NULL,
  delivery_email TEXT NOT NULL,
  delivery_phone TEXT DEFAULT '',
  coupon_code TEXT,
  discount_amount NUMERIC(10,2) DEFAULT 0,
  final_price NUMERIC(10,2) NOT NULL,
  payment_ref TEXT,
  receipt_url TEXT,
  card_code TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS coupons (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code TEXT UNIQUE NOT NULL,
  discount_type TEXT NOT NULL DEFAULT 'percentage' CHECK (discount_type IN ('percentage', 'fixed')),
  discount_value NUMERIC(10,2) NOT NULL,
  min_order_amount NUMERIC(10,2) DEFAULT 0,
  max_uses INTEGER,
  current_uses INTEGER DEFAULT 0,
  expires_at TIMESTAMPTZ,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS coupon_usage (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  coupon_id UUID REFERENCES coupons(id) ON DELETE CASCADE,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  order_id UUID REFERENCES orders(id) ON DELETE CASCADE,
  used_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  subject TEXT DEFAULT '',
  message TEXT NOT NULL,
  is_read BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS announcements (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  text TEXT NOT NULL,
  color TEXT DEFAULT '#ffffff',
  bg_color TEXT DEFAULT '#F59E0B',
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS activity_log (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  details JSONB DEFAULT '{}',
  ip_address TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS site_settings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  key TEXT UNIQUE NOT NULL,
  value TEXT NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS legal_consent (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  consent_type TEXT NOT NULL CHECK (consent_type IN ('terms', 'privacy')),
  ip_address TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ╔══════════════════════════════════════════╗
-- ║  الخطوة 2: تفعيل Row Level Security     ║
-- ╚══════════════════════════════════════════╝

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE coupons ENABLE ROW LEVEL SECURITY;
ALTER TABLE coupon_usage ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE announcements ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE site_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE legal_consent ENABLE ROW LEVEL SECURITY;

-- ╔══════════════════════════════════════════╗
-- ║  الخطوة 3: حذف السياسات القديمة         ║
-- ╚══════════════════════════════════════════╝

DO $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN (
    SELECT schemaname, tablename, policyname 
    FROM pg_policies 
    WHERE schemaname = 'public'
  ) LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON %I.%I', r.policyname, r.schemaname, r.tablename);
  END LOOP;
END;
$$;

-- ╔══════════════════════════════════════════╗
-- ║  الخطوة 4: إنشاء السياسات الجديدة       ║
-- ╚══════════════════════════════════════════╝

-- ▸ profiles
CREATE POLICY "profiles_select" ON profiles FOR SELECT USING (true);
CREATE POLICY "profiles_insert" ON profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "profiles_update" ON profiles FOR UPDATE USING (
  auth.uid() = id OR EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'moderator'))
);

-- ▸ products
CREATE POLICY "products_select" ON products FOR SELECT USING (true);
CREATE POLICY "products_admin" ON products FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'moderator'))
);

-- ▸ orders
CREATE POLICY "orders_select" ON orders FOR SELECT USING (
  user_id = auth.uid() OR EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'moderator'))
);
CREATE POLICY "orders_insert" ON orders FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "orders_admin" ON orders FOR UPDATE USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'moderator'))
);
CREATE POLICY "orders_delete" ON orders FOR DELETE USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'moderator'))
);

-- ▸ coupons
CREATE POLICY "coupons_select" ON coupons FOR SELECT USING (true);
CREATE POLICY "coupons_admin" ON coupons FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'moderator'))
);

-- ▸ coupon_usage
CREATE POLICY "coupon_usage_select" ON coupon_usage FOR SELECT USING (
  user_id = auth.uid() OR EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'moderator'))
);
CREATE POLICY "coupon_usage_insert" ON coupon_usage FOR INSERT WITH CHECK (auth.uid() = user_id);

-- ▸ messages
CREATE POLICY "messages_insert" ON messages FOR INSERT WITH CHECK (true);
CREATE POLICY "messages_admin" ON messages FOR SELECT USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'moderator'))
);
CREATE POLICY "messages_update" ON messages FOR UPDATE USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'moderator'))
);

-- ▸ announcements
CREATE POLICY "announcements_select" ON announcements FOR SELECT USING (true);
CREATE POLICY "announcements_admin" ON announcements FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'moderator'))
);

-- ▸ activity_log
CREATE POLICY "activity_log_insert" ON activity_log FOR INSERT WITH CHECK (true);
CREATE POLICY "activity_log_select" ON activity_log FOR SELECT USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'moderator'))
);

-- ▸ site_settings
CREATE POLICY "site_settings_select" ON site_settings FOR SELECT USING (true);
CREATE POLICY "site_settings_admin" ON site_settings FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'moderator'))
);

-- ▸ legal_consent
CREATE POLICY "legal_consent_insert" ON legal_consent FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "legal_consent_admin" ON legal_consent FOR SELECT USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'moderator'))
);

-- ╔══════════════════════════════════════════╗
-- ║  الخطوة 5: Trigger إنشاء بروفايل تلقائي ║
-- ╚══════════════════════════════════════════╝

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, phone)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    COALESCE(NEW.raw_user_meta_data->>'phone', '')
  );
  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- ╔══════════════════════════════════════════╗
-- ║  الخطوة 6: Storage Bucket للأوصال        ║
-- ╚══════════════════════════════════════════╝

INSERT INTO storage.buckets (id, name, public)
VALUES ('receipts', 'receipts', true)
ON CONFLICT (id) DO NOTHING;

-- ╔══════════════════════════════════════════╗
-- ║  الخطوة 7: بيانات افتراضية               ║
-- ╚══════════════════════════════════════════╝

INSERT INTO site_settings (key, value) VALUES
  ('ccp_number', '0000000000'),
  ('rip_number', '00000000000000000000'),
  ('account_name', 'اسم صاحب الحساب'),
  ('site_name', 'ديجي كارد'),
  ('site_description', 'متجر البطاقات الرقمية الأول في الجزائر'),
  ('admin_secret_code', 'diji2024')
ON CONFLICT (key) DO NOTHING;

INSERT INTO announcements (text, color, bg_color, is_active) VALUES
  ('🎉 مرحبا بكم في ديجي كارد! أسعار مميزة على جميع البطاقات', '#ffffff', '#F59E0B', true);

INSERT INTO products (name, description, category, original_price, sell_price, icon) VALUES
  ('بطاقة Google Play 5$',  'بطاقة Google Play 5 دولار',   'google-play',  850,  750,  '🎮'),
  ('بطاقة Google Play 10$', 'بطاقة Google Play 10 دولار',  'google-play',  1600, 1450, '🎮'),
  ('بطاقة Google Play 25$', 'بطاقة Google Play 25 دولار',  'google-play',  3900, 3500, '🎮'),
  ('بطاقة Google Play 50$', 'بطاقة Google Play 50 دولار',  'google-play',  7600, 6900, '🎮'),
  ('اشتراك Netflix شهر',    'اشتراك Netflix شهر واحد',     'netflix',      3500, 2900, '🎬'),
  ('اشتراك Netflix 3 أشهر', 'اشتراك Netflix 3 أشهر',       'netflix',      9500, 8200, '🎬'),
  ('بطاقة PlayStation 10$', 'بطاقة PlayStation 10 دولار',   'playstation',  1700, 1500, '🕹️'),
  ('بطاقة PlayStation 25$', 'بطاقة PlayStation 25 دولار',   'playstation',  4000, 3600, '🕹️'),
  ('بطاقة Xbox 25$',        'بطاقة Xbox 25 دولار',          'xbox',         4000, 3600, '🎮'),
  ('بطاقة iTunes 25$',      'بطاقة iTunes 25 دولار',        'itunes',       4000, 3600, '🎵'),
  ('اشتراك Spotify شهر',    'اشتراك Spotify شهر',           'spotify',      2000, 1700, '🎶'),
  ('شحن Free Fire 1000',    'شحن 1000 diamond Free Fire',    'free-fire',    2200, 1900, '🔥');

INSERT INTO coupons (code, discount_type, discount_value, min_order_amount, max_uses, expires_at) VALUES
  ('WELCOME10', 'percentage', 10, 500, 100, '2025-12-31T23:59:59')
ON CONFLICT (code) DO NOTHING;

-- ╔══════════════════════════════════════════╗
-- ║  الخطوة 8: إنشاء بروفايلات ناقصة        ║
-- ╚══════════════════════════════════════════╝

INSERT INTO profiles (id, email, full_name, phone, role, is_active)
SELECT 
  u.id,
  u.email,
  COALESCE(u.raw_user_meta_data->>'full_name', split_part(u.email, '@', 1)),
  COALESCE(u.raw_user_meta_data->>'phone', ''),
  'customer',
  true
FROM auth.users u
LEFT JOIN profiles p ON p.id = u.id
WHERE p.id IS NULL;

-- ✅ انتهى!
