import { isSupabaseConfigured, supabase } from './supabase';
import type {
  User, Product, Order, Coupon, Message,
  Announcement, ActivityLog, SiteSetting, SiteConfig
} from '../types';

// ========== Helper ==========
const genId = () => crypto.randomUUID();

// ========== Mock Data Store ==========
const MOCK_USERS: User[] = [
  {
    id: 'admin-001',
    email: 'admin@dijicard.dz',
    full_name: 'المدير العام',
    phone: '0550000000',
    role: 'admin',
    permissions: ['orders', 'products', 'users', 'coupons', 'messages', 'announcements', 'settings', 'activity_log'],
    is_active: true,
    created_at: new Date().toISOString()
  }
];

let MOCK_PRODUCTS: Product[] = [
  { id: 'p1', name: 'بطاقة Google Play 5$', description: 'بطاقة Google Play بقيمة 5 دولار أمريكي', category: 'google-play', original_price: 850, sell_price: 750, icon: '🎮', image_url: '', is_active: true, stock: 100, created_at: new Date().toISOString() },
  { id: 'p2', name: 'بطاقة Google Play 10$', description: 'بطاقة Google Play بقيمة 10 دولار أمريكي', category: 'google-play', original_price: 1600, sell_price: 1450, icon: '🎮', image_url: '', is_active: true, stock: 100, created_at: new Date().toISOString() },
  { id: 'p3', name: 'بطاقة Google Play 25$', description: 'بطاقة Google Play بقيمة 25 دولار أمريكي', category: 'google-play', original_price: 3900, sell_price: 3500, icon: '🎮', image_url: '', is_active: true, stock: 100, created_at: new Date().toISOString() },
  { id: 'p4', name: 'بطاقة Google Play 50$', description: 'بطاقة Google Play بقيمة 50 دولار أمريكي', category: 'google-play', original_price: 7600, sell_price: 6900, icon: '🎮', image_url: '', is_active: true, stock: 100, created_at: new Date().toISOString() },
  { id: 'p5', name: 'اشتراك Netflix شهر واحد', description: 'اشتراك Netflix بريميوم لمدة شهر واحد', category: 'netflix', original_price: 3500, sell_price: 2900, icon: '🎬', image_url: '', is_active: true, stock: 50, created_at: new Date().toISOString() },
  { id: 'p6', name: 'اشتراك Netflix 3 أشهر', description: 'اشتراك Netflix بريميوم لمدة 3 أشهر', category: 'netflix', original_price: 9500, sell_price: 8200, icon: '🎬', image_url: '', is_active: true, stock: 30, created_at: new Date().toISOString() },
  { id: 'p7', name: 'بطاقة PlayStation 10$', description: 'بطاقة PlayStation Store بقيمة 10 دولار', category: 'playstation', original_price: 1700, sell_price: 1500, icon: '🕹️', image_url: '', is_active: true, stock: 50, created_at: new Date().toISOString() },
  { id: 'p8', name: 'بطاقة PlayStation 25$', description: 'بطاقة PlayStation Store بقيمة 25 دولار', category: 'playstation', original_price: 4000, sell_price: 3600, icon: '🕹️', image_url: '', is_active: true, stock: 50, created_at: new Date().toISOString() },
  { id: 'p9', name: 'بطاقة Xbox 25$', description: 'بطاقة Xbox Gift Card بقيمة 25 دولار', category: 'xbox', original_price: 4000, sell_price: 3600, icon: '🎮', image_url: '', is_active: true, stock: 40, created_at: new Date().toISOString() },
  { id: 'p10', name: 'بطاقة iTunes 25$', description: 'بطاقة iTunes/App Store بقيمة 25 دولار', category: 'itunes', original_price: 4000, sell_price: 3600, icon: '🎵', image_url: '', is_active: true, stock: 40, created_at: new Date().toISOString() },
  { id: 'p11', name: 'اشتراك Spotify شهر', description: 'اشتراك Spotify Premium لمدة شهر', category: 'spotify', original_price: 2000, sell_price: 1700, icon: '🎶', image_url: '', is_active: true, stock: 50, created_at: new Date().toISOString() },
  { id: 'p12', name: 'شحن Free Fire 1000', description: '1000 diamond ل لعبة Free Fire', category: 'free-fire', original_price: 2200, sell_price: 1900, icon: '🔥', image_url: '', is_active: true, stock: 100, created_at: new Date().toISOString() },
];

let MOCK_ORDERS: Order[] = [];
let MOCK_COUPONS: Coupon[] = [
  { id: 'c1', code: 'WELCOME10', discount_type: 'percentage', discount_value: 10, min_order_amount: 500, max_uses: 100, current_uses: 0, expires_at: '2025-12-31T23:59:59', is_active: true, created_at: new Date().toISOString() }
];
let MOCK_COUPON_USAGE: { id: string; coupon_id: string; user_id: string; order_id: string; used_at: string }[] = [];
let MOCK_MESSAGES: Message[] = [];
let MOCK_ANNOUNCEMENTS: Announcement[] = [
  { id: 'a1', text: '🎉 مرحبا بكم في ديجي كارد! أسعار مميزة على جميع البطاقات', color: '#ffffff', bg_color: '#F59E0B', is_active: true, created_at: new Date().toISOString() }
];
let MOCK_ACTIVITY_LOG: ActivityLog[] = [];
let MOCK_SETTINGS: SiteSetting[] = [
  { id: 's1', key: 'ccp_number', value: '0000000000', updated_at: new Date().toISOString() },
  { id: 's2', key: 'rip_number', value: '00000000000000000000', updated_at: new Date().toISOString() },
  { id: 's3', key: 'account_name', value: 'اسم صاحب الحساب', updated_at: new Date().toISOString() },
  { id: 's4', key: 'site_name', value: 'ديجي كارد', updated_at: new Date().toISOString() },
  { id: 's5', key: 'site_description', value: 'متجر البطاقات الرقمية الأول في الجزائر', updated_at: new Date().toISOString() },
];

// Current user for mock mode
let mockCurrentUser: User | null = null;

// ========== Password Hashing (simple for mock) ==========
const mockPasswords: Record<string, string> = { 'admin@dijicard.dz': 'admin123' };

// ========== Database Service ==========
export const db = {
  // ===== AUTH STATE LISTENER =====
  onAuthStateChange(callback: (event: string, user: { id: string; email: string; user_metadata?: Record<string, string> } | null) => void) {
    if (isSupabaseConfigured && supabase) {
      const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
        if (session?.user) {
          callback(event, {
            id: session.user.id,
            email: session.user.email || '',
            user_metadata: session.user.user_metadata as Record<string, string> || {}
          });
        } else {
          callback(event, null);
        }
      });
      return { data: { subscription } };
    }
    return { data: { subscription: { unsubscribe: () => {} } } };
  },

  // ===== HELPERS =====
  async _forceCreateProfile(userId: string, email: string, fullName: string, phone: string): Promise<User> {
    if (!supabase) throw new Error('غير متصل');

    // 1. حاول نقرأ البروفايل
    const { data: existing } = await supabase.from('profiles').select('*').eq('id', userId).single();
    if (existing) return existing as User;

    // 2. حاول INSERT مباشرة
    const newProfile = {
      id: userId, email, full_name: fullName, phone,
      role: 'customer' as const, permissions: [] as string[], is_active: true,
    };
    const { data: inserted, error: e1 } = await supabase.from('profiles').insert(newProfile).select().single();
    if (inserted) return inserted as User;
    console.warn('INSERT فشل:', e1?.message);

    // 3. حاول UPSERT
    const { data: upserted, error: e2 } = await supabase.from('profiles').upsert(newProfile).select().single();
    if (upserted) return upserted as User;
    console.warn('UPSERT فشل:', e2?.message);

    // 4. كل شيء فشل → ارجع بروفايل مؤقت (المستخدم يقدر يستعمل الموقع)
    console.error('فشل إنشاء البروفايل نهائياً');
    return { ...newProfile, created_at: new Date().toISOString() };
  },

  async getOrCreateProfile(userId: string, email: string, fullName: string, phone: string): Promise<User> {
    if (!supabase) throw new Error('قاعدة البيانات غير متصلة');
    
    // حاول نجلب البروفايل
    const { data: profile } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();

    if (profile) return profile as User;

    // البروفايل غير موجود → أنشئه
    const newProfile = {
      id: userId,
      email,
      full_name: fullName,
      phone,
      role: 'customer' as const,
      permissions: [] as string[],
      is_active: true,
    };

    const { data: inserted, error: insertError } = await supabase
      .from('profiles')
      .insert(newProfile)
      .select()
      .single();

    if (insertError || !inserted) {
      // لو فشل INSERT، جرّب UPSERT
      const { data: upserted, error: upsertError } = await supabase
        .from('profiles')
        .upsert(newProfile)
        .select()
        .single();

      if (upsertError || !upserted) {
        // لو كل شيء فشل، ارجع بروفايل وهمي عشان الأقل
        console.error('فشل إنشاء البروفايل:', insertError, upsertError);
        return { ...newProfile, created_at: new Date().toISOString() };
      }
      return upserted as User;
    }

    return inserted as User;
  },

  // ===== AUTH =====
  async login(email: string, password: string): Promise<User | null> {
    if (isSupabaseConfigured && supabase) {
      // الخطوة 1: تسجيل دخول من Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signInWithPassword({ email, password });
      
      if (authError) {
        const msg = authError.message || '';
        console.error('🔴 Auth Error:', msg);
        if (msg.includes('Invalid login credentials')) {
          throw new Error('إيميل أو كلمة مرور غالطة. تأكد من البيانات وأعد المحاولة.');
        }
        if (msg.includes('Email not confirmed')) {
          throw new Error('لazm تأكيد الإيميل أولًا! راح لصندوق الوارد (Inbox/Spam) واضغط على الرابط.');
        }
        if (msg.includes('Too many requests')) {
          throw new Error('محاولات كثيرة! استنى دقيقة وحاول مرة أخرى.');
        }
        // أظهر الخطأ الحقيقي عشان نفهم المشكلة
        throw new Error('خطأ من Supabase: ' + msg);
      }

      // الخطوة 2: نجلب أو ننشئ البروفايل
      if (authData.user) {
        const meta = authData.user.user_metadata || {};
        
        try {
          const profile = await this.getOrCreateProfile(
            authData.user.id,
            authData.user.email || email,
            meta.full_name || meta.name || email.split('@')[0],
            meta.phone || ''
          );

          if (!profile.is_active) {
            throw new Error('حسابك معطل. تواصل مع الإدارة.');
          }

          return profile;
        } catch (profileErr: any) {
          // لو فشل جلب البروفايل، سجّل دخول عادي بدون بروفايل كامل
          console.error('🔴 Profile Error:', profileErr.message);
          return {
            id: authData.user.id,
            email: authData.user.email || email,
            full_name: meta.full_name || email.split('@')[0],
            phone: meta.phone || '',
            role: 'customer' as const,
            permissions: [] as string[],
            is_active: true,
            created_at: new Date().toISOString()
          };
        }
      }
      return null;
    } else {
      // Mock mode
      const user = MOCK_USERS.find(u => u.email === email);
      if (!user) throw new Error('البريد الإلكتروني أو كلمة المرور غير صحيحة');
      if (mockPasswords[email] !== password) throw new Error('البريد الإلكتروني أو كلمة المرور غير صحيحة');
      if (!user.is_active) throw new Error('حسابك معطل. تواصل مع الإدارة.');
      mockCurrentUser = user;
      return user;
    }
  },

  async register(email: string, password: string, fullName: string, phone: string): Promise<User> {
    if (isSupabaseConfigured && supabase) {
      // تسجيل في Supabase Auth
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: { full_name: fullName, phone }
        }
      });
      
      if (error) {
        const msg = error.message;
        if (msg.includes('already registered')) throw new Error('هذا البريد الإلكتروني مسجل بالفعل');
        if (msg.includes('Password')) throw new Error('كلمة المرور ضعيفة. استخدم 6 أحرف على الأقل');
        throw new Error('خطأ: ' + msg);
      }

      if (data.user) {
        // ننتظر عشان الـ trigger
        await new Promise(r => setTimeout(r, 1500));

        // حاول نبعت البروفايل مباشرة (RLS ممكن يمنع)
        let profile = await this._forceCreateProfile(data.user.id, email, fullName, phone);

        // لو في تأكيد إيميل
        if (!data.session) {
          throw new Error('CONFIRM_EMAIL');
        }

        return profile;
      }
      throw new Error('فشل في إنشاء الحساب');
    } else {
      // Mock mode
      const exists = MOCK_USERS.find(u => u.email === email);
      if (exists) throw new Error('هذا البريد الإلكتروني مستخدم بالفعل');
      const newUser: User = {
        id: genId(),
        email,
        full_name: fullName,
        phone,
        role: 'customer',
        permissions: [],
        is_active: true,
        created_at: new Date().toISOString()
      };
      MOCK_USERS.push(newUser);
      mockPasswords[email] = password;
      mockCurrentUser = newUser;
      return newUser;
    }
  },

  async logout(): Promise<void> {
    if (isSupabaseConfigured && supabase) {
      await supabase.auth.signOut();
    } else {
      mockCurrentUser = null;
    }
  },

  async getCurrentUser(): Promise<User | null> {
    if (isSupabaseConfigured && supabase) {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.user) {
          const meta = session.user.user_metadata || {};
          const userId = session.user.id;
          const email = session.user.email || '';
          const fullName = meta.full_name || meta.name || email.split('@')[0];
          const phone = meta.phone || '';

          // حاول اقرأ البروفايل
          const { data: profile } = await supabase.from('profiles').select('*').eq('id', userId).single();
          if (profile) return profile as User;

          // البروفايل غير موجود → أنشئه
          return await this._forceCreateProfile(userId, email, fullName, phone);
        }
      } catch {}
      return null;
    } else {
      return mockCurrentUser;
    }
  },

  // ===== PRODUCTS =====
  async getProducts(): Promise<Product[]> {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('is_active', true)
        .order('sell_price', { ascending: true });
      if (error) throw error;
      return data as Product[];
    }
    return MOCK_PRODUCTS.filter(p => p.is_active);
  },

  async getAllProducts(): Promise<Product[]> {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data as Product[];
    }
    return [...MOCK_PRODUCTS];
  },

  async getProduct(id: string): Promise<Product | null> {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('id', id)
        .single();
      if (error) throw error;
      return data as Product;
    }
    return MOCK_PRODUCTS.find(p => p.id === id) || null;
  },

  async createProduct(product: Omit<Product, 'id' | 'created_at'>): Promise<Product> {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase.from('products').insert(product).select().single();
      if (error) { console.error('خطأ إضافة منتج:', error.message); throw new Error('فشل إضافة المنتج: ' + error.message); }
      return data as Product;
    }
    const newProduct: Product = { ...product, id: genId(), created_at: new Date().toISOString() };
    MOCK_PRODUCTS.push(newProduct);
    return newProduct;
  },

  async updateProduct(id: string, updates: Partial<Product>): Promise<void> {
    if (isSupabaseConfigured && supabase) {
      const { error } = await supabase.from('products').update(updates).eq('id', id);
      if (error) { console.error('خطأ تعديل منتج:', error.message); throw new Error('فشل تعديل المنتج: ' + error.message); }
    } else {
      const idx = MOCK_PRODUCTS.findIndex(p => p.id === id);
      if (idx !== -1) MOCK_PRODUCTS[idx] = { ...MOCK_PRODUCTS[idx], ...updates };
    }
  },

  async deleteProduct(id: string): Promise<void> {
    if (isSupabaseConfigured && supabase) {
      const { error } = await supabase.from('products').delete().eq('id', id);
      if (error) { console.error('خطأ حذف منتج:', error.message); throw new Error('فشل حذف المنتج: ' + error.message); }
    } else {
      MOCK_PRODUCTS = MOCK_PRODUCTS.filter(p => p.id !== id);
    }
  },

  // ===== ORDERS =====
  async createOrder(order: Omit<Order, 'id' | 'created_at' | 'updated_at' | 'status'>): Promise<Order> {
    if (isSupabaseConfigured && supabase) {
      const product = await this.getProduct(order.product_id);
      if (!product) throw new Error('المنتج غير موجود');
      const { data, error } = await supabase.from('orders').insert({ ...order, status: 'pending' }).select().single();
      if (error) { console.error('خطأ إنشاء طلب:', error.message); throw new Error('فشل إنشاء الطلب: ' + error.message); }
      return data as Order;
    }
    const newOrder: Order = {
      ...order,
      id: genId(),
      status: 'pending',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    MOCK_ORDERS.push(newOrder);
    return newOrder;
  },

  async getUserOrders(userId: string): Promise<Order[]> {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase
        .from('orders')
        .select('*, products(name)')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return (data as any[]).map(o => ({ ...o, product_name: o.products?.name }));
    }
    return MOCK_ORDERS.filter(o => o.user_id === userId).map(o => {
      const product = MOCK_PRODUCTS.find(p => p.id === o.product_id);
      return { ...o, product_name: product?.name };
    });
  },

  async getAllOrders(): Promise<Order[]> {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase
        .from('orders')
        .select('*, products(name)')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return (data as any[]).map(o => ({ ...o, product_name: o.products?.name }));
    }
    return MOCK_ORDERS.map(o => {
      const product = MOCK_PRODUCTS.find(p => p.id === o.product_id);
      return { ...o, product_name: product?.name };
    });
  },

  async updateOrderStatus(id: string, status: Order['status'], cardCode?: string, notes?: string): Promise<void> {
    if (isSupabaseConfigured && supabase) {
      const updates: any = { status, updated_at: new Date().toISOString() };
      if (cardCode) updates.card_code = cardCode;
      if (notes) updates.notes = notes;
      const { error } = await supabase.from('orders').update(updates).eq('id', id);
      if (error) { console.error('خطأ تحديث طلب:', error.message); throw new Error('فشل تحديث الطلب: ' + error.message); }
    } else {
      const idx = MOCK_ORDERS.findIndex(o => o.id === id);
      if (idx !== -1) {
        MOCK_ORDERS[idx].status = status;
        MOCK_ORDERS[idx].updated_at = new Date().toISOString();
        if (cardCode) MOCK_ORDERS[idx].card_code = cardCode;
        if (notes) MOCK_ORDERS[idx].notes = notes;
      }
    }
  },

  // ===== COUPONS =====
  async validateCoupon(code: string, userId: string, orderAmount: number): Promise<Coupon> {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase
        .from('coupons')
        .select('*')
        .eq('code', code)
        .eq('is_active', true)
        .single();
      if (error || !data) throw new Error('كود الخصم غير صالح');
      
      const coupon = data as Coupon;
      if (coupon.expires_at && new Date(coupon.expires_at) < new Date())
        throw new Error('انتهت صلاحية كود الخصم');
      if (coupon.min_order_amount > orderAmount)
        throw new Error(`الحد الأدنى للطلب ${coupon.min_order_amount} د.ج`);
      if (coupon.max_uses && coupon.current_uses >= coupon.max_uses)
        throw new Error('تم استخدام هذا الكوبون للحد الأقصى');
      
      // Check if user already used this coupon
      const { data: usage } = await supabase
        .from('coupon_usage')
        .select('id')
        .eq('coupon_id', coupon.id)
        .eq('user_id', userId)
        .single();
      if (usage) throw new Error('لقد استخدمت هذا الكوبون من قبل');
      
      return coupon;
    }
    // Mock
    const coupon = MOCK_COUPONS.find(c => c.code === code && c.is_active);
    if (!coupon) throw new Error('كود الخصم غير صالح');
    if (coupon.expires_at && new Date(coupon.expires_at) < new Date())
      throw new Error('انتهت صلاحية كود الخصم');
    if (coupon.min_order_amount > orderAmount)
      throw new Error(`الحد الأدنى للطلب ${coupon.min_order_amount} د.ج`);
    if (coupon.max_uses && coupon.current_uses >= coupon.max_uses)
      throw new Error('تم استخدام هذا الكوبون للحد الأقصى');
    const alreadyUsed = MOCK_COUPON_USAGE.find(u => u.coupon_id === coupon.id && u.user_id === userId);
    if (alreadyUsed) throw new Error('لقد استخدمت هذا الكوبون من قبل');
    return coupon;
  },

  async useCoupon(couponId: string, userId: string, orderId: string): Promise<void> {
    if (isSupabaseConfigured && supabase) {
      await supabase.from('coupon_usage').insert({ coupon_id: couponId, user_id: userId, order_id: orderId });
      await supabase.rpc('increment_coupon_usage', { coupon_id_input: couponId });
    } else {
      MOCK_COUPON_USAGE.push({ id: genId(), coupon_id: couponId, user_id: userId, order_id: orderId, used_at: new Date().toISOString() });
      const coupon = MOCK_COUPONS.find(c => c.id === couponId);
      if (coupon) coupon.current_uses++;
    }
  },

  async getAllCoupons(): Promise<Coupon[]> {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase.from('coupons').select('*').order('created_at', { ascending: false });
      if (error) throw error;
      return data as Coupon[];
    }
    return [...MOCK_COUPONS];
  },

  async createCoupon(coupon: Omit<Coupon, 'id' | 'created_at' | 'current_uses'>): Promise<Coupon> {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase.from('coupons').insert({ ...coupon, current_uses: 0 }).select().single();
      if (error) throw error;
      return data as Coupon;
    }
    const newCoupon: Coupon = { ...coupon, id: genId(), current_uses: 0, created_at: new Date().toISOString() };
    MOCK_COUPONS.push(newCoupon);
    return newCoupon;
  },

  async deleteCoupon(id: string): Promise<void> {
    if (isSupabaseConfigured && supabase) {
      const { error } = await supabase.from('coupons').delete().eq('id', id);
      if (error) throw error;
    } else {
      MOCK_COUPONS = MOCK_COUPONS.filter(c => c.id !== id);
    }
  },

  // ===== MESSAGES =====
  async sendMessage(msg: Omit<Message, 'id' | 'created_at' | 'is_read'>): Promise<void> {
    if (isSupabaseConfigured && supabase) {
      const { error } = await supabase.from('messages').insert({ ...msg, is_read: false });
      if (error) throw error;
    } else {
      MOCK_MESSAGES.push({ ...msg, id: genId(), is_read: false, created_at: new Date().toISOString() });
    }
  },

  async getAllMessages(): Promise<Message[]> {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase.from('messages').select('*').order('created_at', { ascending: false });
      if (error) throw error;
      return data as Message[];
    }
    return [...MOCK_MESSAGES];
  },

  async markMessageRead(id: string): Promise<void> {
    if (isSupabaseConfigured && supabase) {
      await supabase.from('messages').update({ is_read: true }).eq('id', id);
    } else {
      const msg = MOCK_MESSAGES.find(m => m.id === id);
      if (msg) msg.is_read = true;
    }
  },

  // ===== ANNOUNCEMENTS =====
  async getActiveAnnouncements(): Promise<Announcement[]> {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase.from('announcements').select('*').eq('is_active', true);
      if (error) throw error;
      return data as Announcement[];
    }
    return MOCK_ANNOUNCEMENTS.filter(a => a.is_active);
  },

  async getAllAnnouncements(): Promise<Announcement[]> {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase.from('announcements').select('*').order('created_at', { ascending: false });
      if (error) throw error;
      return data as Announcement[];
    }
    return [...MOCK_ANNOUNCEMENTS];
  },

  async createAnnouncement(ann: Omit<Announcement, 'id' | 'created_at'>): Promise<Announcement> {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase.from('announcements').insert(ann).select().single();
      if (error) throw error;
      return data as Announcement;
    }
    const newAnn: Announcement = { ...ann, id: genId(), created_at: new Date().toISOString() };
    MOCK_ANNOUNCEMENTS.push(newAnn);
    return newAnn;
  },

  async updateAnnouncement(id: string, updates: Partial<Announcement>): Promise<void> {
    if (isSupabaseConfigured && supabase) {
      const { error } = await supabase.from('announcements').update(updates).eq('id', id);
      if (error) throw error;
    } else {
      const idx = MOCK_ANNOUNCEMENTS.findIndex(a => a.id === id);
      if (idx !== -1) MOCK_ANNOUNCEMENTS[idx] = { ...MOCK_ANNOUNCEMENTS[idx], ...updates };
    }
  },

  async deleteAnnouncement(id: string): Promise<void> {
    if (isSupabaseConfigured && supabase) {
      const { error } = await supabase.from('announcements').delete().eq('id', id);
      if (error) throw error;
    } else {
      MOCK_ANNOUNCEMENTS = MOCK_ANNOUNCEMENTS.filter(a => a.id !== id);
    }
  },

  // ===== USERS =====
  async getAllUsers(): Promise<User[]> {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase.from('profiles').select('*').order('created_at', { ascending: false });
      if (error) throw error;
      return data as User[];
    }
    return [...MOCK_USERS];
  },

  async updateUserRole(id: string, role: string, permissions: string[]): Promise<void> {
    if (isSupabaseConfigured && supabase) {
      const { error } = await supabase.from('profiles').update({ role, permissions }).eq('id', id);
      if (error) throw error;
    } else {
      const user = MOCK_USERS.find(u => u.id === id);
      if (user) { user.role = role as any; user.permissions = permissions; }
    }
  },

  async toggleUserActive(id: string): Promise<void> {
    if (isSupabaseConfigured && supabase) {
      const { data } = await supabase.from('profiles').select('is_active').eq('id', id).single();
      if (data) {
        await supabase.from('profiles').update({ is_active: !data.is_active }).eq('id', id);
      }
    } else {
      const user = MOCK_USERS.find(u => u.id === id);
      if (user) user.is_active = !user.is_active;
    }
  },

  // ===== ACTIVITY LOG =====
  async logActivity(userId: string | undefined, action: string, details: Record<string, unknown> = {}): Promise<void> {
    if (isSupabaseConfigured && supabase) {
      await supabase.from('activity_log').insert({ user_id: userId, action, details });
    } else {
      const user = userId ? MOCK_USERS.find(u => u.id === userId) : null;
      MOCK_ACTIVITY_LOG.push({
        id: genId(),
        user_id: userId,
        user_name: user?.full_name || 'نظام',
        action,
        details,
        created_at: new Date().toISOString()
      });
    }
  },

  async getActivityLog(): Promise<ActivityLog[]> {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase
        .from('activity_log')
        .select('*, profiles(full_name)')
        .order('created_at', { ascending: false })
        .limit(100);
      if (error) throw error;
      return (data as any[]).map(l => ({ ...l, user_name: l.profiles?.full_name }));
    }
    return [...MOCK_ACTIVITY_LOG];
  },

  // ===== SITE SETTINGS =====
  async getSetting(key: string): Promise<string | null> {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase.from('site_settings').select('value').eq('key', key).single();
      if (error) return 'ERR:' + error.message;
      return data?.value ?? null;
    }
    return null;
  },

  async getSiteConfig(): Promise<SiteConfig> {
    if (isSupabaseConfigured && supabase) {
      const { data, error } = await supabase.from('site_settings').select('*');
      if (error) throw error;
      const settings = (data || []) as SiteSetting[];
      return {
        ccp_number: settings.find(s => s.key === 'ccp_number')?.value || '',
        rip_number: settings.find(s => s.key === 'rip_number')?.value || '',
        account_name: settings.find(s => s.key === 'account_name')?.value || '',
        site_name: settings.find(s => s.key === 'site_name')?.value || 'ديجي كارد',
        site_description: settings.find(s => s.key === 'site_description')?.value || '',
      };
    }
    return {
      ccp_number: MOCK_SETTINGS.find(s => s.key === 'ccp_number')?.value || '',
      rip_number: MOCK_SETTINGS.find(s => s.key === 'rip_number')?.value || '',
      account_name: MOCK_SETTINGS.find(s => s.key === 'account_name')?.value || '',
      site_name: MOCK_SETTINGS.find(s => s.key === 'site_name')?.value || 'ديجي كارد',
      site_description: MOCK_SETTINGS.find(s => s.key === 'site_description')?.value || '',
    };
  },

  async updateSiteSetting(key: string, value: string): Promise<string> {
    if (!isSupabaseConfigured || !supabase) {
      throw new Error('Supabase غير متصل');
    }

    // استعمل UPSERT (إدخال أو تحديث)
    const { data, error } = await supabase
      .from('site_settings')
      .upsert(
        { key, value, updated_at: new Date().toISOString() },
        { onConflict: 'key' }
      )
      .select()
      .single();

    if (error) {
      throw new Error('فشل UPSERT: ' + error.message);
    }

    return data?.value ?? 'لا نتيجة';
  },

  // ===== LEGAL CONSENT =====
  async recordConsent(userId: string, consentType: 'terms' | 'privacy'): Promise<void> {
    if (isSupabaseConfigured && supabase) {
      await supabase.from('legal_consent').insert({ user_id: userId, consent_type: consentType });
    }
    // Mock mode: no-op
  },

  // ===== STATS (Dashboard) =====
  async getDashboardStats(): Promise<{
    totalRevenue: number;
    totalOrders: number;
    pendingOrders: number;
    totalUsers: number;
    totalProducts: number;
    unreadMessages: number;
  }> {
    const orders = await this.getAllOrders();
    const users = await this.getAllUsers();
    const products = await this.getAllProducts();
    const messages = await this.getAllMessages();

    return {
      totalRevenue: orders.filter(o => o.status === 'delivered').reduce((sum, o) => sum + o.final_price, 0),
      totalOrders: orders.length,
      pendingOrders: orders.filter(o => o.status === 'pending').length,
      totalUsers: users.length,
      totalProducts: products.length,
      unreadMessages: messages.filter(m => !m.is_read).length,
    };
  },
};
