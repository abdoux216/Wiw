import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://zvbdilaganamnmrglbuc.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inp2YmRpbGFnYW5hbW5tcmdsYnVjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzgzNTkwODUsImV4cCI6MjA5MzkzNTA4NX0.IKySIwFZHirMHnhndR6knOufACzR2lGCg6HfiG4o-Dg';

export const isSupabaseConfigured = true;
export const supabase = createClient(supabaseUrl, supabaseKey);
