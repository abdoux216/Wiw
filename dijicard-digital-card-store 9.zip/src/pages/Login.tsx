import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { Mail, Lock, LogIn, Shield, AlertTriangle } from 'lucide-react';

export default function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const { addToast } = useToast();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (!email || !password) {
      addToast('يرجى ملء جميع الحقول', 'warning');
      return;
    }
    setLoading(true);
    try {
      const user = await login(email, password);
      addToast(`مرحباً بك ${user.full_name}!`, 'success');
      if (user.role === 'admin' || user.role === 'moderator') {
        navigate('/admin');
      } else {
        navigate('/');
      }
    } catch (err: any) {
      const msg = err.message || 'فشل في تسجيل الدخول';
      setErrorMsg(msg);
      addToast(msg, 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-900 via-gray-800 to-amber-900 px-4 py-12">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 right-20 w-72 h-72 bg-amber-400 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-20 w-96 h-96 bg-amber-600 rounded-full blur-3xl" />
      </div>

      <div className="relative w-full max-w-md">
        <div className="bg-white rounded-3xl shadow-2xl p-8 animate-fadeIn">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-amber-400 to-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
              <LogIn className="w-7 h-7 text-white" />
            </div>
            <h1 className="text-2xl font-black text-gray-800">تسجيل الدخول</h1>
            <p className="text-sm text-gray-500 mt-1">أدخل بياناتك للوصول لحسابك</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">البريد الإلكتروني</label>
              <div className="relative">
                <Mail className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="email"
                  value={email}
                  onChange={e => { setEmail(e.target.value); setErrorMsg(''); }}
                  placeholder="example@email.com"
                  className="w-full pr-11 pl-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-amber-400 focus:ring-2 focus:ring-amber-100 outline-none transition-all text-sm"
                  dir="ltr"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">كلمة المرور</label>
              <div className="relative">
                <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="password"
                  value={password}
                  onChange={e => { setPassword(e.target.value); setErrorMsg(''); }}
                  placeholder="••••••••"
                  className="w-full pr-11 pl-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-amber-400 focus:ring-2 focus:ring-amber-100 outline-none transition-all text-sm"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-gradient-to-l from-amber-500 to-amber-600 text-white font-bold text-sm rounded-xl hover:from-amber-600 hover:to-amber-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-amber-200/50"
            >
              {loading ? 'جاري الدخول...' : 'تسجيل الدخول'}
            </button>
          </form>

          {/* رسالة خطأ مفصلة */}
          {errorMsg && (
            <div className={`mt-4 rounded-xl p-4 animate-fadeIn ${
              errorMsg.includes('Supabase') ? 'bg-orange-50 border border-orange-200' :
              errorMsg.includes('معطل') ? 'bg-red-50 border border-red-200' :
              errorMsg.includes('تأكيد') ? 'bg-blue-50 border border-blue-200' :
              'bg-red-50 border border-red-200'
            }`}>
              <div className="flex items-start gap-2">
                <AlertTriangle className={`w-5 h-5 flex-shrink-0 mt-0.5 ${
                  errorMsg.includes('Supabase') ? 'text-orange-500' :
                  errorMsg.includes('تأكيد') ? 'text-blue-500' :
                  'text-red-500'
                }`} />
                <div className="flex-1">
                  <p className="text-sm font-semibold text-gray-800 mb-1">{errorMsg}</p>
                  
                  {errorMsg.includes('غالطة') && (
                    <div className="text-xs text-gray-500 space-y-1 mt-2">
                      <p className="font-medium text-gray-600">تأكد من:</p>
                      <p>• الإيميل مكتوب صح (حروف صغيرة وكبيرة)</p>
                      <p>• كلمة المرور صحيحة</p>
                      <p>• الحساب مسجل فعلاً في النظام</p>
                    </div>
                  )}

                  {errorMsg.includes('تأكيد') && (
                    <div className="text-xs text-gray-500 space-y-1 mt-2">
                      <p>• راح لصندوق الوارد (Inbox)</p>
                      <p>• شوف مجلد Spam/Junk</p>
                      <p>• اضغط على رابط التأكيد</p>
                    </div>
                  )}

                  {errorMsg.includes('Supabase') && (
                    <div className="text-xs text-orange-600 space-y-1 mt-2">
                      <p className="font-medium">🔍 تفاصيل تقنية (أرسلها للمطور):</p>
                      <p className="font-mono bg-orange-100 p-2 rounded mt-1" dir="ltr">{errorMsg}</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          <div className="mt-6 text-center">
            <p className="text-sm text-gray-500">
              ليس لديك حساب؟{' '}
              <Link to="/register" className="text-amber-600 font-semibold hover:text-amber-700">
                سجل الآن
              </Link>
            </p>
          </div>

          {/* Legal Warning */}
          <div className="mt-6 bg-red-50 rounded-xl p-3 flex items-start gap-2">
            <Shield className="w-4 h-4 text-red-500 mt-0.5 flex-shrink-0" />
            <p className="text-[11px] text-red-600 leading-relaxed">
              تحذير: جميع محاولات الدخول مسجلة. أي محاولة وصول غير مصرح بها ستعرضك للمتابعة القانونية وفقاً للمواد 372-375 من قانون العقوبات الجزائري.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
