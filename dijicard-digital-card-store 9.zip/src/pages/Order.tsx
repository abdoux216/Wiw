import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { db } from '../lib/database';
import type { Product, Coupon, SiteConfig } from '../types';
import { ArrowLeft, ArrowRight, Copy, Upload, Tag, CheckCircle, CreditCard, Image, FileText } from 'lucide-react';

const STEPS = [
  { label: 'المنتج', icon: FileText },
  { label: 'بيانات الاستلام', icon: CreditCard },
  { label: 'معلومات الدفع', icon: CreditCard },
  { label: 'رفع الوصل', icon: Image },
];

export default function Order() {
  const navigate = useNavigate();
  const { productId } = useParams();
  const { user } = useAuth();
  const { addToast } = useToast();

  const [step, setStep] = useState(0);
  const [product, setProduct] = useState<Product | null>(null);
  const [siteConfig, setSiteConfig] = useState<SiteConfig | null>(null);
  const [loading, setLoading] = useState(false);

  // Form state
  const [deliveryName, setDeliveryName] = useState(user?.full_name || '');
  const [deliveryEmail, setDeliveryEmail] = useState(user?.email || '');
  const [deliveryPhone, setDeliveryPhone] = useState(user?.phone || '');
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [discountAmount, setDiscountAmount] = useState(0);
  const [receiptFile, setReceiptFile] = useState<File | null>(null);
  const [receiptPreview, setReceiptPreview] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    if (productId) {
      db.getProduct(productId).then(p => {
        if (p) setProduct(p);
        else navigate('/');
      }).catch(() => navigate('/'));
    }
    db.getSiteConfig().then(setSiteConfig).catch(() => {});
  }, [productId, user]);

  const finalPrice = product ? Math.max(0, product.sell_price - discountAmount) : 0;

  const handleApplyCoupon = async () => {
    if (!couponCode.trim() || !product || !user) return;
    try {
      const coupon = await db.validateCoupon(couponCode, user.id, product.sell_price);
      setAppliedCoupon(coupon);
      if (coupon.discount_type === 'percentage') {
        setDiscountAmount(Math.round(product.sell_price * coupon.discount_value / 100));
      } else {
        setDiscountAmount(coupon.discount_value);
      }
      addToast('تم تطبيق كود الخصم بنجاح! 🎉', 'success');
    } catch (err: any) {
      setAppliedCoupon(null);
      setDiscountAmount(0);
      addToast(err.message || 'كود الخصم غير صالح', 'error');
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        addToast('حجم الملف يجب أن يكون أقل من 5MB', 'error');
        return;
      }
      setReceiptFile(file);
      const reader = new FileReader();
      reader.onload = (ev) => setReceiptPreview(ev.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      addToast('تم النسخ بنجاح!', 'success');
    }).catch(() => {
      addToast('فشل في النسخ', 'error');
    });
  };

  const handleSubmit = async () => {
    if (!product || !user) return;
    setLoading(true);
    try {
      let receiptUrl = '';
      // In a real app, upload to Supabase Storage
      if (receiptFile) {
        receiptUrl = receiptPreview || 'receipt_uploaded';
      }

      const order = await db.createOrder({
        user_id: user.id,
        product_id: product.id,
        delivery_name: deliveryName,
        delivery_email: deliveryEmail,
        delivery_phone: deliveryPhone,
        coupon_code: appliedCoupon?.code,
        discount_amount: discountAmount,
        final_price: finalPrice,
        receipt_url: receiptUrl,
      });

      if (appliedCoupon) {
        await db.useCoupon(appliedCoupon.id, user.id, order.id);
      }

      await db.logActivity(user.id, 'طلب جديد', { orderId: order.id, product: product.name, price: finalPrice });

      addToast('تم إرسال طلبك بنجاح! سيتم مراجعته قريباً 🎉', 'success');
      navigate('/my-orders');
    } catch (err: any) {
      addToast(err.message || 'فشل في إرسال الطلب', 'error');
    } finally {
      setLoading(false);
    }
  };

  const canProceed = () => {
    switch (step) {
      case 0: return !!product;
      case 1: return deliveryName.trim() && deliveryEmail.trim();
      case 2: return true;
      case 3: return !!receiptFile;
      default: return false;
    }
  };

  const formatPrice = (price: number) => new Intl.NumberFormat('ar-DZ').format(price);

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-10 h-10 border-4 border-amber-500 border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-2xl mx-auto px-4">
        {/* Back button */}
        <button
          onClick={() => step === 0 ? navigate('/') : setStep(step - 1)}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-800 mb-6 text-sm font-medium"
        >
          <ArrowRight className="w-4 h-4" />
          {step === 0 ? 'العودة للمنتجات' : 'الخطوة السابقة'}
        </button>

        {/* Progress Steps */}
        <div className="flex items-center justify-between mb-8 bg-white rounded-2xl p-4 shadow-sm">
          {STEPS.map((s, i) => (
            <div key={i} className="flex flex-col items-center flex-1">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold transition-all ${
                i <= step ? 'bg-amber-500 text-white' : 'bg-gray-100 text-gray-400'
              }`}>
                {i < step ? <CheckCircle className="w-5 h-5" /> : i + 1}
              </div>
              <span className={`text-[11px] mt-1 font-medium ${i <= step ? 'text-amber-600' : 'text-gray-400'}`}>
                {s.label}
              </span>
            </div>
          ))}
        </div>

        {/* Step Content */}
        <div className="bg-white rounded-2xl shadow-sm p-6 animate-fadeIn">
          {/* Step 0: Product Summary */}
          {step === 0 && (
            <div>
              <h2 className="text-xl font-bold text-gray-800 mb-4">تأكيد المنتج</h2>
              <div className="flex items-center gap-4 bg-gray-50 rounded-xl p-4 mb-6">
                {product.image_url ? (
                  <img src={product.image_url} alt={product.name} className="w-16 h-16 object-contain rounded-lg"
                    onError={e => { e.currentTarget.style.display = 'none'; (e.currentTarget.nextElementSibling as HTMLElement).style.display = 'block'; }} />
                ) : null}
                <div className={`text-4xl ${product.image_url ? 'hidden' : ''}`}>{product.icon}</div>
                <div className="flex-1">
                  <h3 className="font-bold text-gray-800">{product.name}</h3>
                  <p className="text-sm text-gray-500">{product.description}</p>
                </div>
                <div className="text-left">
                  <div className="text-lg font-black text-amber-600">{formatPrice(product.sell_price)} د.ج</div>
                  {product.original_price > product.sell_price && (
                    <div className="text-xs text-gray-400 line-through">{formatPrice(product.original_price)} د.ج</div>
                  )}
                </div>
              </div>

              {/* Coupon */}
              <div className="border border-gray-200 rounded-xl p-4">
                <label className="block text-sm font-semibold text-gray-700 mb-2">هل لديك كود خصم؟</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={couponCode}
                    onChange={e => setCouponCode(e.target.value.toUpperCase())}
                    placeholder="أدخل الكود هنا..."
                    className="flex-1 px-4 py-2 bg-gray-50 rounded-lg border border-gray-200 text-sm outline-none focus:border-amber-400"
                    dir="ltr"
                  />
                  <button
                    onClick={handleApplyCoupon}
                    className="px-4 py-2 bg-amber-500 text-white text-sm font-bold rounded-lg hover:bg-amber-600 transition-colors flex items-center gap-1"
                  >
                    <Tag className="w-4 h-4" />
                    تطبيق
                  </button>
                </div>
                {appliedCoupon && (
                  <div className="mt-2 bg-green-50 text-green-700 text-sm px-3 py-2 rounded-lg flex items-center gap-2">
                    <CheckCircle className="w-4 h-4" />
                    خصم {appliedCoupon.discount_type === 'percentage' ? `${appliedCoupon.discount_value}%` : `${appliedCoupon.discount_value} د.ج`} مطبق!
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Step 1: Delivery Info */}
          {step === 1 && (
            <div>
              <h2 className="text-xl font-bold text-gray-800 mb-4">بيانات الاستلام</h2>
              <p className="text-sm text-gray-500 mb-6">أدخل البيانات التي ستستلم عليها الكود</p>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">الاسم الكامل</label>
                  <input
                    type="text"
                    value={deliveryName}
                    onChange={e => setDeliveryName(e.target.value)}
                    placeholder="الاسم الذي ستستلم عليه"
                    className="w-full px-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-amber-400 focus:ring-2 focus:ring-amber-100 outline-none transition-all text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">البريد الإلكتروني</label>
                  <input
                    type="email"
                    value={deliveryEmail}
                    onChange={e => setDeliveryEmail(e.target.value)}
                    placeholder="بريدك الإلكتروني"
                    className="w-full px-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-amber-400 focus:ring-2 focus:ring-amber-100 outline-none transition-all text-sm"
                    dir="ltr"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">رقم الهاتف (اختياري)</label>
                  <input
                    type="tel"
                    value={deliveryPhone}
                    onChange={e => setDeliveryPhone(e.target.value)}
                    placeholder="05XXXXXXXX"
                    className="w-full px-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-amber-400 focus:ring-2 focus:ring-amber-100 outline-none transition-all text-sm"
                    dir="ltr"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Step 2: Payment Info */}
          {step === 2 && siteConfig && (
            <div>
              <h2 className="text-xl font-bold text-gray-800 mb-4">معلومات الدفع</h2>
              <p className="text-sm text-gray-500 mb-6">قم بتحويل المبلغ عبر تطبيق بريدي موب إلى الحساب التالي</p>

              {/* Amount to pay */}
              <div className="bg-amber-50 border-2 border-amber-200 rounded-xl p-4 mb-6 text-center">
                <p className="text-sm text-amber-700 font-medium mb-1">المبلغ المطلوب تحويله</p>
                <p className="text-3xl font-black text-amber-600">{formatPrice(finalPrice)} <span className="text-lg">د.ج</span></p>
                {discountAmount > 0 && (
                  <p className="text-xs text-green-600 mt-1">تم تخصيم {formatPrice(discountAmount)} د.ج</p>
                )}
              </div>

              {/* Payment Details */}
              <div className="space-y-3">
                <div className="flex items-center justify-between bg-gray-50 rounded-xl p-4">
                  <div>
                    <p className="text-xs text-gray-500">رقم الحساب البريدي (CCP)</p>
                    <p className="font-bold text-gray-800 mt-0.5" dir="ltr">{siteConfig.ccp_number}</p>
                  </div>
                  <button
                    onClick={() => copyToClipboard(siteConfig.ccp_number)}
                    className="p-2 bg-amber-100 rounded-lg hover:bg-amber-200 transition-colors"
                  >
                    <Copy className="w-4 h-4 text-amber-600" />
                  </button>
                </div>

                <div className="flex items-center justify-between bg-gray-50 rounded-xl p-4">
                  <div>
                    <p className="text-xs text-gray-500">رقم RIP</p>
                    <p className="font-bold text-gray-800 mt-0.5 text-sm" dir="ltr">{siteConfig.rip_number}</p>
                  </div>
                  <button
                    onClick={() => copyToClipboard(siteConfig.rip_number)}
                    className="p-2 bg-amber-100 rounded-lg hover:bg-amber-200 transition-colors"
                  >
                    <Copy className="w-4 h-4 text-amber-600" />
                  </button>
                </div>

                <div className="flex items-center justify-between bg-gray-50 rounded-xl p-4">
                  <div>
                    <p className="text-xs text-gray-500">اسم صاحب الحساب</p>
                    <p className="font-bold text-gray-800 mt-0.5">{siteConfig.account_name}</p>
                  </div>
                  <button
                    onClick={() => copyToClipboard(siteConfig.account_name)}
                    className="p-2 bg-amber-100 rounded-lg hover:bg-amber-200 transition-colors"
                  >
                    <Copy className="w-4 h-4 text-amber-600" />
                  </button>
                </div>
              </div>

              <div className="mt-4 bg-blue-50 rounded-xl p-3">
                <p className="text-xs text-blue-700">
                  💡 بعد التحويل، خد لقطة شاشة (Screenshot) لوصل التحويل من تطبيق بريدي موب وارفعها في الخطوة التالية
                </p>
              </div>
            </div>
          )}

          {/* Step 3: Upload Receipt */}
          {step === 3 && (
            <div>
              <h2 className="text-xl font-bold text-gray-800 mb-4">رفع وصل التحويل</h2>
              <p className="text-sm text-gray-500 mb-6">ارفع صورة وصل التحويل من تطبيق بريدي موب</p>

              {/* Summary */}
              <div className="bg-gray-50 rounded-xl p-4 mb-6">
                <h3 className="font-bold text-gray-800 mb-2">ملخص الطلب</h3>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between"><span className="text-gray-500">المنتج:</span><span className="font-medium">{product.name}</span></div>
                  <div className="flex justify-between"><span className="text-gray-500">السعر:</span><span className="font-medium">{formatPrice(product.sell_price)} د.ج</span></div>
                  {discountAmount > 0 && (
                    <div className="flex justify-between text-green-600"><span>الخصم:</span><span>-{formatPrice(discountAmount)} د.ج</span></div>
                  )}
                  <div className="flex justify-between border-t border-gray-200 pt-1 mt-1">
                    <span className="font-bold text-gray-800">الإجمالي:</span>
                    <span className="font-black text-amber-600">{formatPrice(finalPrice)} د.ج</span>
                  </div>
                </div>
              </div>

              {/* Upload Area */}
              <label className="block border-2 border-dashed border-gray-300 rounded-xl p-8 text-center cursor-pointer hover:border-amber-400 hover:bg-amber-50/30 transition-all">
                <input type="file" accept="image/*" onChange={handleFileChange} className="hidden" />
                {receiptPreview ? (
                  <div>
                    <img src={receiptPreview} alt="وصل التحويل" className="max-h-48 mx-auto rounded-lg mb-3" />
                    <p className="text-sm text-green-600 font-medium">✅ تم رفع الصورة بنجاح - اضغط لتغييرها</p>
                  </div>
                ) : (
                  <div>
                    <Upload className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                    <p className="text-sm text-gray-600 font-medium">اضغط هنا لرفع صورة الوصل</p>
                    <p className="text-xs text-gray-400 mt-1">PNG, JPG حتى 5MB</p>
                  </div>
                )}
              </label>
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex justify-between mt-6 pt-4 border-t border-gray-100">
            {step > 0 ? (
              <button
                onClick={() => setStep(step - 1)}
                className="px-6 py-2.5 bg-gray-100 text-gray-700 font-medium text-sm rounded-xl hover:bg-gray-200 transition-colors flex items-center gap-2"
              >
                <ArrowRight className="w-4 h-4" />
                السابق
              </button>
            ) : <div />}

            {step < 3 ? (
              <button
                onClick={() => canProceed() && setStep(step + 1)}
                disabled={!canProceed()}
                className="px-6 py-2.5 bg-gradient-to-l from-amber-500 to-amber-600 text-white font-bold text-sm rounded-xl hover:from-amber-600 hover:to-amber-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-amber-200/50 flex items-center gap-2"
              >
                التالي
                <ArrowLeft className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                disabled={!canProceed() || loading}
                className="px-8 py-2.5 bg-gradient-to-l from-green-500 to-green-600 text-white font-bold text-sm rounded-xl hover:from-green-600 hover:to-green-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-green-200/50 flex items-center gap-2"
              >
                {loading ? 'جاري الإرسال...' : '✅ إرسال الطلب'}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
