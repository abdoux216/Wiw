import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { db } from '../lib/database';
import type { User } from '../types';
import { KeyRound, Mail, Lock, Eye, EyeOff, Shield, Ban } from 'lucide-react';

const MAX_CODE_ATTEMPTS = 3;
const BLOCK_SECONDS = 60;

export default function AdminLogin() {
  const navigate = useNavigate();
  const { login, setAdminSession, user } = useAuth();
  const { addToast } = useToast();

  const [adminCode, setAdminCode] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showCode, setShowCode] = useState(false);
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [codeAttempts, setCodeAttempts] = useState(0);
  const [blocked, setBlocked] = useState(false);
  const [blockTimer, setBlockTimer] = useState(0);
  const [errorMsg, setErrorMsg] = useState('');

  // لو الأدمن داخل بالفعل
  useEffect(() => {
    if (user && (user.role === 'admin' || user.role === 'moderator')) {
      navigate('/admin');
    }
  }, [user]);

  useEffect(() => {
    if (blockTimer > 0) {
      const t = setTimeout(() => setBlockTimer(blockTimer - 1), 1000);
      return () => clearTimeout(t);
    } else if (blocked) {
      setBlocked(false);
      setCodeAttempts(0);
    }
  }, [blockTimer, blocked]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (blocked) return;
    if (!adminCode || !email || !password) {
      addToast('يرجى ملء جميع الحقول', 'warning');
      return;
    }
    setErrorMsg('');
    setLoading(true);

    try {
      // ═══ 1. الكود السري ═══
      const dbCode = await db.getSetting('admin_secret_code');
      const validCode = dbCode || 'diji2024';

      if (adminCode !== validCode) {
        const remaining = MAX_CODE_ATTEMPTS - codeAttempts - 1;
        setCodeAttempts(prev => prev + 1);
        setAdminCode('');
        if (remaining <= 0) {
          setBlocked(true);
          setBlockTimer(BLOCK_SECONDS);
          addToast(`⛔ حظر ${BLOCK_SECONDS} ثانية`, 'error');
        } else {
          addToast(`❌ كود خاطئ! متبقي ${remaining}`, 'error');
        }
        setLoading(false);
        return;
      }

      // ═══ 2. محاولة دخول عبر Supabase Auth ═══
      let adminUser: User | null = null;
      try {
        adminUser = await login(email, password);
        if (adminUser.role !== 'admin' && adminUser.role !== 'moderator') {
          adminUser = null;
        }
      } catch {
        adminUser = null;
      }

      // ═══ 3. لو Supabase فشل، تحقق من site_settings ═══
      if (!adminUser) {
        const dbEmail = await db.getSetting('admin_email');
        const dbPassword = await db.getSetting('admin_password');

        if (dbEmail && dbPassword && email === dbEmail && password === dbPassword) {
          adminUser = {
            id: 'admin-session',
            email: dbEmail,
            full_name: 'المدير',
            phone: '',
            role: 'admin',
            permissions: ['orders', 'products', 'users', 'coupons', 'messages', 'announcements', 'settings', 'activity_log'],
            is_active: true,
            created_at: new Date().toISOString()
          };
        }
      }

      // ═══ 4. النتيجة ═══
      if (adminUser) {
        await setAdminSession(adminUser);
        addToast(`✅ مرحباً ${adminUser.full_name}!`, 'success');
        navigate('/admin');
      } else {
        setErrorMsg('❌ إيميل أو كلمة مرور خاطئة');
        addToast('إيميل أو كلمة مرور خاطئة', 'error');
      }

    } catch (err: any) {
      setErrorMsg(err.message || 'حدث خطأ');
      addToast(err.message || 'حدث خطأ', 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 px-4 py-12">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl" />
      </div>

      <div className="relative w-full max-w-md">
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-amber-500/20 to-amber-600/20 rounded-full border border-amber-500/30 mb-3">
            {blocked ? <Ban className="w-7 h-7 text-red-500 animate-pulse" /> : <KeyRound className="w-7 h-7 text-amber-500" />}
          </div>
          <h1 className="text-xl font-black text-white">لوحة التحكم</h1>
          <p className="text-xs text-gray-500 flex items-center justify-center gap-1 mt-1">
            <Shield className="w-3 h-3" /> منطقة محمية
          </p>
        </div>

        {codeAttempts > 0 && !blocked && (
          <div className="flex justify-center gap-2 mb-4">
            {Array.from({ length: MAX_CODE_ATTEMPTS }).map((_, i) => (
              <div key={i} className={`w-3 h-3 rounded-full ${i < codeAttempts ? 'bg-red-500' : 'bg-gray-700'}`} />
            ))}
            <span className="text-xs text-gray-500 mr-2">متبقي {MAX_CODE_ATTEMPTS - codeAttempts}</span>
          </div>
        )}

        <div className="bg-gray-900/80 backdrop-blur-xl rounded-3xl border border-gray-800 p-6 shadow-2xl animate-fadeIn">

          {blocked ? (
            <div className="text-center py-6">
              <Ban className="w-14 h-14 text-red-500 mx-auto mb-4 animate-pulse" />
              <p className="text-red-400 font-bold text-lg mb-2">⛔ تم الحظر</p>
              <p className="text-gray-500 text-sm mb-4">حاول مرة أخرى بعد</p>
              <div className="text-4xl font-black text-red-400">{blockTimer}</div>
              <p className="text-gray-600 text-xs mt-1">ثانية</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-400 mb-1.5">🔑 الكود السري</label>
                <div className="relative">
                  <KeyRound className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-600" />
                  <input type={showCode ? 'text' : 'password'} value={adminCode} onChange={e => setAdminCode(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pr-10 pl-10 py-3 bg-gray-800/80 rounded-xl border border-gray-700 focus:border-amber-500 outline-none text-sm text-white placeholder-gray-600 tracking-widest" dir="ltr" />
                  <button type="button" onClick={() => setShowCode(!showCode)} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-600 hover:text-gray-400">
                    {showCode ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 mb-1.5">📧 البريد الإلكتروني</label>
                <div className="relative">
                  <Mail className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-600" />
                  <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="admin@email.com"
                    className="w-full pr-10 pl-4 py-3 bg-gray-800/80 rounded-xl border border-gray-700 focus:border-amber-500 outline-none text-sm text-white placeholder-gray-600" dir="ltr" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 mb-1.5">🔒 كلمة المرور</label>
                <div className="relative">
                  <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-600" />
                  <input type={showPass ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••"
                    className="w-full pr-10 pl-10 py-3 bg-gray-800/80 rounded-xl border border-gray-700 focus:border-amber-500 outline-none text-sm text-white placeholder-gray-600" dir="ltr" />
                  <button type="button" onClick={() => setShowPass(!showPass)} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-600 hover:text-gray-400">
                    {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button type="submit" disabled={loading}
                className="w-full py-3.5 bg-gradient-to-l from-amber-500 to-amber-600 text-white font-bold text-sm rounded-xl hover:from-amber-600 hover:to-amber-700 transition-all disabled:opacity-50 shadow-lg shadow-amber-500/20 mt-2">
                {loading ? '⏳ جاري التحقق...' : '🔓 دخول'}
              </button>

              {errorMsg && (
                <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-3 animate-fadeIn">
                  <p className="text-xs text-red-400 font-bold">{errorMsg}</p>
                </div>
              )}

              <button type="button" onClick={() => navigate('/')} className="w-full py-2 text-gray-500 text-xs hover:text-gray-300 transition-colors">
                ← العودة للمتجر
              </button>
            </form>
          )}
        </div>
        <div className="mt-4 text-center">
          <p className="text-[10px] text-gray-600">⚠️ جميع المحاولات مسجلة</p>
        </div>
      </div>
    </div>
  );
}
