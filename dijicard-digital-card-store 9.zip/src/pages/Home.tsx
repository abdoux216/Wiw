import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../lib/database';
import type { Product } from '../types';
import { Search, Tag, TrendingUp, Shield, Zap, ArrowLeft } from 'lucide-react';

const CATEGORIES = [
  { key: 'all', label: 'الكل', icon: '🏷️' },
  { key: 'google-play', label: 'Google Play', icon: '🎮' },
  { key: 'netflix', label: 'Netflix', icon: '🎬' },
  { key: 'playstation', label: 'PlayStation', icon: '🕹️' },
  { key: 'xbox', label: 'Xbox', icon: '🎮' },
  { key: 'itunes', label: 'iTunes', icon: '🎵' },
  { key: 'spotify', label: 'Spotify', icon: '🎶' },
  { key: 'free-fire', label: 'Free Fire', icon: '🔥' },
];

export default function Home() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    db.getProducts().then(prods => {
      setProducts(prods);
      setFilteredProducts(prods);
    }).catch(() => {}).finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    let filtered = products;
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(p => p.category === selectedCategory);
    }
    if (searchQuery.trim()) {
      filtered = filtered.filter(p =>
        p.name.includes(searchQuery) || p.description.includes(searchQuery)
      );
    }
    setFilteredProducts(filtered);
  }, [selectedCategory, searchQuery, products]);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('ar-DZ').format(price);
  };

  const handleBuy = (product: Product) => {
    if (!user) {
      navigate('/login');
      return;
    }
    navigate(`/order/${product.id}`);
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-gray-900 via-gray-800 to-amber-900 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 right-10 w-72 h-72 bg-amber-400 rounded-full blur-3xl" />
          <div className="absolute bottom-10 left-10 w-96 h-96 bg-amber-600 rounded-full blur-3xl" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
          <div className="text-center">
            <div className="inline-flex items-center gap-2 bg-amber-500/20 text-amber-300 px-4 py-2 rounded-full text-sm font-medium mb-6">
              <Zap className="w-4 h-4" />
              أسعار السوق الموازي بالدينار الجزائري
            </div>
            <h1 className="text-3xl sm:text-5xl font-black text-white mb-4 leading-tight">
              بطاقات رقمية <span className="text-amber-400">بأسعار مميزة</span>
            </h1>
            <p className="text-gray-300 text-lg max-w-2xl mx-auto mb-8">
              اشترِ بطاقات Google Play، Netflix، PlayStation وأكثر بكل سهولة وأمان عبر بريدي موب
            </p>
            <div className="flex flex-wrap justify-center gap-4 text-sm">
              <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-lg text-white">
                <Shield className="w-4 h-4 text-green-400" />
                <span>دفع آمن 100%</span>
              </div>
              <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-lg text-white">
                <Zap className="w-4 h-4 text-amber-400" />
                <span>تسليم فوري</span>
              </div>
              <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-lg text-white">
                <TrendingUp className="w-4 h-4 text-blue-400" />
                <span>أفضل الأسعار</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Products Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        {/* Search and Filter */}
        <div className="mb-8">
          {/* Search */}
          <div className="relative mb-4">
            <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="ابحث عن منتج..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pr-12 pl-4 py-3 bg-white rounded-xl border border-gray-200 focus:border-amber-400 focus:ring-2 focus:ring-amber-100 outline-none transition-all text-sm"
            />
          </div>

          {/* Category Filter */}
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {CATEGORIES.map(cat => (
              <button
                key={cat.key}
                onClick={() => setSelectedCategory(cat.key)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all ${
                  selectedCategory === cat.key
                    ? 'bg-amber-500 text-white shadow-lg shadow-amber-200'
                    : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-200'
                }`}
              >
                <span>{cat.icon}</span>
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Products Grid */}
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {[1, 2, 3, 4, 5, 6, 7, 8].map(i => (
              <div key={i} className="bg-white rounded-2xl p-6 animate-pulse">
                <div className="w-16 h-16 bg-gray-200 rounded-xl mx-auto mb-4" />
                <div className="h-4 bg-gray-200 rounded mb-2 w-3/4 mx-auto" />
                <div className="h-3 bg-gray-200 rounded mb-4 w-1/2 mx-auto" />
                <div className="h-8 bg-gray-200 rounded-lg" />
              </div>
            ))}
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="text-center py-16">
            <div className="text-6xl mb-4">🔍</div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">لا توجد منتجات</h3>
            <p className="text-gray-500">جرب البحث بكلمات أخرى أو اختر فئة مختلفة</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {filteredProducts.map((product, idx) => (
              <div
                key={product.id}
                className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 group animate-fadeIn border border-gray-100"
                style={{ animationDelay: `${idx * 50}ms` }}
              >
                {/* Product Image or Icon */}
                <div className="bg-gradient-to-br from-gray-50 to-gray-100 p-2 text-center relative overflow-hidden" style={{ minHeight: '140px' }}>
                  {product.image_url ? (
                    <img
                      src={product.image_url}
                      alt={product.name}
                      className="w-full h-36 object-contain rounded-xl group-hover:scale-105 transition-transform duration-300"
                      onError={e => {
                        e.currentTarget.style.display = 'none';
                        const parent = e.currentTarget.parentElement;
                        if (parent) {
                          const fallback = parent.querySelector('.icon-fallback') as HTMLElement;
                          if (fallback) fallback.style.display = 'flex';
                        }
                      }}
                    />
                  ) : null}
                  <div className={`items-center justify-center ${product.image_url ? 'hidden icon-fallback' : 'flex'}`} style={{ height: '140px' }}>
                    <div className="text-5xl group-hover:scale-110 transition-transform duration-300">
                      {product.icon}
                    </div>
                  </div>
                  <span className="absolute bottom-1 left-1 text-[10px] text-gray-400 bg-white/80 backdrop-blur-sm px-2 py-0.5 rounded-full">
                    {CATEGORIES.find(c => c.key === product.category)?.label || product.category}
                  </span>
                </div>

                {/* Product Info */}
                <div className="p-4">
                  <h3 className="font-bold text-gray-800 text-sm mb-1">{product.name}</h3>
                  <p className="text-xs text-gray-500 mb-3">{product.description}</p>

                  {/* Prices */}
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-black text-amber-600">
                          {formatPrice(product.sell_price)}
                        </span>
                        <span className="text-xs text-gray-400">د.ج</span>
                      </div>
                      {product.original_price > product.sell_price && (
                        <div className="flex items-center gap-1">
                          <span className="text-xs text-gray-400 line-through">
                            {formatPrice(product.original_price)}
                          </span>
                          <span className="text-xs text-green-600 font-semibold">
                            -{Math.round(((product.original_price - product.sell_price) / product.original_price) * 100)}%
                          </span>
                        </div>
                      )}
                    </div>
                    <Tag className="w-4 h-4 text-green-500" />
                  </div>

                  {/* Buy Button */}
                  <button
                    onClick={() => handleBuy(product)}
                    className="w-full py-2.5 bg-gradient-to-l from-amber-500 to-amber-600 text-white font-bold text-sm rounded-xl hover:from-amber-600 hover:to-amber-700 transition-all duration-300 flex items-center justify-center gap-2 shadow-lg shadow-amber-200/50 active:scale-95"
                  >
                    <span>شراء الآن</span>
                    <ArrowLeft className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Legal Warning Banner */}
      <div className="bg-red-50 border-t border-red-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 text-center">
          <p className="text-sm text-red-700 font-medium">
            ⚖️ تحذير قانوني: جميع المعاملات مسجلة وموثقة. أي محاولة احتيال ستعرضك للمتابعة القانونية وفقاً للمواد 372-375 من قانون العقوبات الجزائري.
          </p>
        </div>
      </div>
    </div>
  );
}
