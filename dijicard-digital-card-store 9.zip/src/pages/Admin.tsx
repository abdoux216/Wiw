import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { db } from '../lib/database';
import type { Product, Order, User as UserType, Coupon, Message, Announcement, ActivityLog } from '../types';
import {
  LayoutDashboard, ShoppingCart, Package, Users, Tag, MessageCircle, Megaphone,
  Activity, Settings, LogOut, Plus, Check, X, Eye, Ban, CheckCircle, XCircle,
  Clock, DollarSign, UserCheck, Search, Edit, Trash2
} from 'lucide-react';

type AdminTab = 'dashboard' | 'orders' | 'products' | 'users' | 'coupons' | 'messages' | 'announcements' | 'activity' | 'settings';

const TABS: { key: AdminTab; label: string; icon: typeof LayoutDashboard }[] = [
  { key: 'dashboard', label: 'لوحة المعلومات', icon: LayoutDashboard },
  { key: 'orders', label: 'الطلبات', icon: ShoppingCart },
  { key: 'products', label: 'المنتجات', icon: Package },
  { key: 'users', label: 'المستخدمين', icon: Users },
  { key: 'coupons', label: 'الكوبونات', icon: Tag },
  { key: 'messages', label: 'الرسائل', icon: MessageCircle },
  { key: 'announcements', label: 'الإعلانات', icon: Megaphone },
  { key: 'activity', label: 'سجل النشاطات', icon: Activity },
  { key: 'settings', label: 'الإعدادات', icon: Settings },
];

const formatPrice = (price: number) => new Intl.NumberFormat('ar-DZ').format(price);
const formatDate = (date: string) => new Date(date).toLocaleDateString('ar-DZ', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });

const STATUS_LABELS: Record<string, string> = {
  pending: 'قيد المراجعة', confirmed: 'تم التأكيد', delivered: 'تم التسليم', rejected: 'مرفوض'
};

export default function Admin() {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const { addToast } = useToast();
  const [activeTab, setActiveTab] = useState<AdminTab>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Data states
  const [stats, setStats] = useState<any>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [users, setUsers] = useState<UserType[]>([]);
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [activityLog, setActivityLog] = useState<ActivityLog[]>([]);
  const [_siteConfig, setSiteConfig] = useState<any>({});

  // Filter states
  const [orderFilter, setOrderFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Modal states
  const [showProductModal, setShowProductModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [showCouponModal, setShowCouponModal] = useState(false);
  const [showAnnouncementModal, setShowAnnouncementModal] = useState(false);
  const [showCardCodeModal, setShowCardCodeModal] = useState<string | null>(null);
  const [cardCode, setCardCode] = useState('');

  const [rejectReason, setRejectReason] = useState('');
  const [showRejectModal, setShowRejectModal] = useState<string | null>(null);
  const [showOrderDetail, setShowOrderDetail] = useState<string | null>(null);

  // Form states
  const [productForm, setProductForm] = useState({
    name: '', description: '', category: 'google-play', original_price: 0, sell_price: 0, icon: '💳', image_url: '', stock: 100, is_active: true
  });
  const [couponForm, setCouponForm] = useState({
    code: '', discount_type: 'percentage' as 'percentage' | 'fixed', discount_value: 0, min_order_amount: 0, max_uses: 100, expires_at: '', is_active: true
  });
  const [announcementForm, setAnnouncementForm] = useState({
    text: '', color: '#ffffff', bg_color: '#F59E0B', is_active: true
  });

  // Site settings form
  const [settingsForm, setSettingsForm] = useState({
    ccp_number: '', rip_number: '', account_name: '', site_name: '', site_description: ''
  });
  const [settingsSaving, setSettingsSaving] = useState(false);
  const [settingsMsg, setSettingsMsg] = useState('');

  // Check admin access
  useEffect(() => {
    if (!user) {
      navigate('/admin-login');
      return;
    }
    if (user.role !== 'admin' && user.role !== 'moderator') {
      navigate('/');
      addToast('ليس لديك صلاحية الوصول لهذه الصفحة', 'error');
      return;
    }
  }, [user]);

  const loadTabData = useCallback(async () => {
    try {
      switch (activeTab) {
        case 'dashboard':
          setStats(await db.getDashboardStats());
          break;
        case 'orders':
          setOrders(await db.getAllOrders());
          break;
        case 'products':
          setProducts(await db.getAllProducts());
          break;
        case 'users':
          setUsers(await db.getAllUsers());
          break;
        case 'coupons':
          setCoupons(await db.getAllCoupons());
          break;
        case 'messages':
          setMessages(await db.getAllMessages());
          break;
        case 'announcements':
          setAnnouncements(await db.getAllAnnouncements());
          break;
        case 'activity':
          setActivityLog(await db.getActivityLog());
          break;
        case 'settings':
          const config = await db.getSiteConfig();
          setSettingsForm(config);
          setSiteConfig(config);
          break;
      }
    } catch (err: any) {
      addToast('فشل في تحميل البيانات', 'error');
    }
  }, [activeTab]);

  useEffect(() => {
    if (user && (user.role === 'admin' || user.role === 'moderator')) {
      loadTabData();
    }
  }, [activeTab, user, loadTabData]);

  if (!user || (user.role !== 'admin' && user.role !== 'moderator')) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-900">
        <div className="text-center">
          <div className="animate-spin w-10 h-10 border-4 border-amber-500 border-t-transparent rounded-full mx-auto mb-4" />
          <p className="text-white">جاري التحقق...</p>
        </div>
      </div>
    );
  }

  // ===== ACTIONS =====
  const handleOrderAction = async (orderId: string, action: string) => {
    try {
      if (action === 'confirm') {
        await db.updateOrderStatus(orderId, 'confirmed');
        addToast('تم تأكيد الطلب', 'success');
      } else if (action === 'deliver' && showCardCodeModal) {
        if (!cardCode.trim()) { addToast('يرجى إدخال كود البطاقة', 'warning'); return; }
        await db.updateOrderStatus(orderId, 'delivered', cardCode);
        setShowCardCodeModal(null);
        setCardCode('');
        addToast('تم تسليم الكود بنجاح!', 'success');
      } else if (action === 'reject' && showRejectModal) {
        if (!rejectReason) { addToast('يرجى اختيار سبب الرفض', 'warning'); return; }
        await db.updateOrderStatus(orderId, 'rejected', undefined, rejectReason);
        setShowRejectModal(null);
        setRejectReason('');
        addToast('تم رفض الطلب', 'info');
      }
      await db.logActivity(user.id, `طلب: ${action}`, { orderId });
      loadTabData();
    } catch (err: any) {
      addToast(err.message || 'فشل في العملية', 'error');
    }
  };

  const handleSaveProduct = async () => {
    try {
      if (editingProduct) {
        await db.updateProduct(editingProduct.id, productForm);
        addToast('تم تعديل المنتج', 'success');
      } else {
        await db.createProduct(productForm);
        addToast('تم إضافة المنتج', 'success');
      }
      await db.logActivity(user.id, editingProduct ? 'تعديل منتج' : 'إضافة منتج', { name: productForm.name });
      setShowProductModal(false);
      setEditingProduct(null);
      loadTabData();
    } catch (err: any) {
      addToast(err.message || 'فشل في حفظ المنتج', 'error');
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا المنتج؟')) return;
    try {
      await db.deleteProduct(id);
      await db.logActivity(user.id, 'حذف منتج', { productId: id });
      addToast('تم حذف المنتج', 'success');
      loadTabData();
    } catch { addToast('فشل في حذف المنتج', 'error'); }
  };

  const handleSaveCoupon = async () => {
    try {
      await db.createCoupon(couponForm);
      await db.logActivity(user.id, 'إضافة كوبون', { code: couponForm.code });
      setShowCouponModal(false);
      addToast('تم إضافة الكوبون', 'success');
      loadTabData();
    } catch (err: any) { addToast(err.message || 'فشل', 'error'); }
  };

  const handleDeleteCoupon = async (id: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا الكوبون؟')) return;
    try {
      await db.deleteCoupon(id);
      addToast('تم حذف الكوبون', 'success');
      loadTabData();
    } catch { addToast('فشل', 'error'); }
  };

  const handleSaveAnnouncement = async () => {
    try {
      await db.createAnnouncement(announcementForm);
      setShowAnnouncementModal(false);
      addToast('تم إضافة الإعلان', 'success');
      loadTabData();
    } catch (err: any) { addToast(err.message || 'فشل', 'error'); }
  };

  const handleDeleteAnnouncement = async (id: string) => {
    if (!confirm('حذف الإعلان؟')) return;
    try {
      await db.deleteAnnouncement(id);
      addToast('تم حذف الإعلان', 'success');
      loadTabData();
    } catch { addToast('فشل', 'error'); }
  };

  const handleToggleAnnouncement = async (id: string, isActive: boolean) => {
    try {
      await db.updateAnnouncement(id, { is_active: !isActive });
      addToast(isActive ? 'تم إيقاف الإعلان' : 'تم تفعيل الإعلان', 'success');
      loadTabData();
    } catch { addToast('فشل', 'error'); }
  };

  const handleToggleUser = async (id: string) => {
    try {
      await db.toggleUserActive(id);
      await db.logActivity(user.id, 'تغيير حالة مستخدم', { userId: id });
      addToast('تم تغيير حالة المستخدم', 'success');
      loadTabData();
    } catch { addToast('فشل', 'error'); }
  };

  const handleUserRole = async (id: string, role: string) => {
    try {
      await db.updateUserRole(id, role, []);
      await db.logActivity(user.id, 'تغيير دور مستخدم', { userId: id, role });
      addToast('تم تغيير الدور', 'success');
      loadTabData();
    } catch { addToast('فشل', 'error'); }
  };

  const handleMarkRead = async (id: string) => {
    try {
      await db.markMessageRead(id);
      loadTabData();
    } catch { /* */ }
  };

  const handleSaveSettings = async () => {
    setSettingsMsg('⏳ جاري الحفظ...');
    setSettingsSaving(true);
    try {
      const results: string[] = [];
      for (const [key, value] of Object.entries(settingsForm)) {
        try {
          // حفظ + استلم القيمة المرجعة
          const returned = await db.updateSiteSetting(key, value);
          
          // تحقق فوري بالقراءة
          const saved = await db.getSetting(key);
          
          results.push(`${key}: أرسلنا="${value}" | رجع="${returned}" | قرأنا="${saved}"`);
        } catch (err: any) {
          results.push(`❌ ${key}: ${err.message}`);
        }
      }

      // إعادة القراءة
      const fresh = await db.getSiteConfig();
      setSettingsForm(fresh);
      
      setSettingsMsg(results.join('\n'));
    } catch (err: any) {
      setSettingsMsg('❌ خطأ عام: ' + err.message);
    } finally {
      setSettingsSaving(false);
    }
  };

  const openProductModal = (product?: Product) => {
    if (product) {
      setEditingProduct(product);
      setProductForm({
        name: product.name, description: product.description, category: product.category,
        original_price: product.original_price, sell_price: product.sell_price,
        icon: product.icon, image_url: product.image_url || '', stock: product.stock, is_active: product.is_active
      });
    } else {
      setEditingProduct(null);
      setProductForm({ name: '', description: '', category: 'google-play', original_price: 0, sell_price: 0, icon: '💳', image_url: '', stock: 100, is_active: true });
    }
    setShowProductModal(true);
  };

  // ===== FILTERED DATA =====
  const filteredOrders = orderFilter === 'all' ? orders : orders.filter(o => o.status === orderFilter);
  const searchedProducts = searchQuery ? products.filter(p => p.name.includes(searchQuery)) : products;

  // ===== RENDER =====
  return (
    <div className="min-h-screen bg-gray-100 flex" style={{ direction: 'rtl' }}>
      {/* Sidebar Overlay */}
      {sidebarOpen && <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />}

      {/* Sidebar */}
      <aside className={`fixed lg:static inset-y-0 right-0 w-64 bg-gray-900 text-white z-50 transition-transform lg:translate-x-0 ${sidebarOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'}`}>
        <div className="p-4 border-b border-gray-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-amber-500 rounded-xl flex items-center justify-center">
              <LayoutDashboard className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-sm">لوحة التحكم</h2>
              <p className="text-[10px] text-gray-400">DIJICARD Admin</p>
            </div>
          </div>
        </div>

        <nav className="p-2 space-y-1">
          {TABS.map(tab => (
            <button
              key={tab.key}
              onClick={() => { setActiveTab(tab.key); setSidebarOpen(false); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                activeTab === tab.key
                  ? 'bg-amber-500 text-white'
                  : 'text-gray-400 hover:text-white hover:bg-gray-800'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
              {tab.key === 'messages' && messages.filter(m => !m.is_read).length > 0 && (
                <span className="mr-auto bg-red-500 text-white text-[10px] px-1.5 py-0.5 rounded-full">
                  {messages.filter(m => !m.is_read).length}
                </span>
              )}
              {tab.key === 'orders' && stats?.pendingOrders > 0 && (
                <span className="mr-auto bg-amber-500 text-white text-[10px] px-1.5 py-0.5 rounded-full">
                  {stats.pendingOrders}
                </span>
              )}
            </button>
          ))}
        </nav>

        <div className="absolute bottom-0 w-full p-4 border-t border-gray-800">
          <button
            onClick={async () => { await logout(); navigate('/'); }}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-red-400 hover:text-white hover:bg-red-600/20 transition-all"
          >
            <LogOut className="w-4 h-4" />
            تسجيل الخروج
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 min-w-0">
        {/* Top Bar */}
        <header className="bg-white shadow-sm px-4 sm:px-6 py-3 flex items-center justify-between sticky top-0 z-30">
          <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-2 rounded-lg hover:bg-gray-50">
            <LayoutDashboard className="w-5 h-5 text-gray-600" />
          </button>
          <h1 className="text-lg font-bold text-gray-800">
            {TABS.find(t => t.key === activeTab)?.label}
          </h1>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-amber-100 rounded-full flex items-center justify-center">
              <UserCheck className="w-4 h-4 text-amber-600" />
            </div>
            <span className="text-sm text-gray-600 hidden sm:block">{user.full_name}</span>
          </div>
        </header>

        <div className="p-4 sm:p-6">
          {/* ===== DASHBOARD ===== */}
          {activeTab === 'dashboard' && stats && (
            <div className="space-y-6 animate-fadeIn">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <StatCard icon={DollarSign} label="الإيرادات" value={`${formatPrice(stats.totalRevenue)} د.ج`} color="bg-green-500" />
                <StatCard icon={ShoppingCart} label="إجمالي الطلبات" value={stats.totalOrders} color="bg-blue-500" />
                <StatCard icon={Clock} label="طلبات الانتظار" value={stats.pendingOrders} color="bg-amber-500" />
                <StatCard icon={Users} label="المستخدمين" value={stats.totalUsers} color="bg-purple-500" />
                <StatCard icon={Package} label="المنتجات" value={stats.totalProducts} color="bg-indigo-500" />
                <StatCard icon={MessageCircle} label="رسائل غير مقروءة" value={stats.unreadMessages} color="bg-red-500" />
              </div>
            </div>
          )}

          {/* ===== ORDERS ===== */}
          {activeTab === 'orders' && (
            <div className="space-y-4 animate-fadeIn">
              {/* Filter tabs */}
              <div className="flex gap-2 overflow-x-auto pb-2">
                {['all', 'pending', 'confirmed', 'delivered', 'rejected'].map(s => (
                  <button
                    key={s}
                    onClick={() => setOrderFilter(s)}
                    className={`px-4 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                      orderFilter === s ? 'bg-amber-500 text-white' : 'bg-white text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    {s === 'all' ? 'الكل' : STATUS_LABELS[s]} ({s === 'all' ? orders.length : orders.filter(o => o.status === s).length})
                  </button>
                ))}
              </div>

              <div className="bg-white rounded-xl shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-gray-50 border-b border-gray-100">
                        <th className="text-right px-4 py-3 font-semibold text-gray-600">العميل</th>
                        <th className="text-right px-4 py-3 font-semibold text-gray-600">المنتج</th>
                        <th className="text-right px-4 py-3 font-semibold text-gray-600">المبلغ</th>
                        <th className="text-right px-4 py-3 font-semibold text-gray-600">الحالة</th>
                        <th className="text-right px-4 py-3 font-semibold text-gray-600">التاريخ</th>
                        <th className="text-right px-4 py-3 font-semibold text-gray-600">إجراءات</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredOrders.map(order => (
                        <tr key={order.id} className="border-b border-gray-50 hover:bg-gray-50/50">
                          <td className="px-4 py-3">
                            <div>
                              <p className="font-medium text-gray-800">{order.delivery_name}</p>
                              <p className="text-xs text-gray-500" dir="ltr">{order.delivery_email}</p>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-gray-700">{order.product_name}</td>
                          <td className="px-4 py-3 font-bold text-amber-600">{formatPrice(order.final_price)} د.ج</td>
                          <td className="px-4 py-3">
                            <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                              order.status === 'pending' ? 'bg-amber-100 text-amber-700' :
                              order.status === 'confirmed' ? 'bg-blue-100 text-blue-700' :
                              order.status === 'delivered' ? 'bg-green-100 text-green-700' :
                              'bg-red-100 text-red-700'
                            }`}>
                              {STATUS_LABELS[order.status]}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-xs text-gray-500">{formatDate(order.created_at)}</td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-1">
                              {/* 👁 عرض التفاصيل */}
                              <button onClick={() => setShowOrderDetail(order.id)} className="p-1.5 rounded-lg bg-indigo-100 hover:bg-indigo-200 transition-colors" title="عرض التفاصيل">
                                <Eye className="w-3.5 h-3.5 text-indigo-600" />
                              </button>
                              {order.status === 'pending' && (
                                <>
                                  <button onClick={() => handleOrderAction(order.id, 'confirm')} className="p-1.5 rounded-lg bg-green-100 hover:bg-green-200 transition-colors" title="تأكيد">
                                    <Check className="w-3.5 h-3.5 text-green-600" />
                                  </button>
                                  <button onClick={() => { setShowRejectModal(order.id); setRejectReason(''); }} className="p-1.5 rounded-lg bg-red-100 hover:bg-red-200 transition-colors" title="رفض">
                                    <X className="w-3.5 h-3.5 text-red-600" />
                                  </button>
                                </>
                              )}
                              {order.status === 'confirmed' && (
                                <button onClick={() => { setShowCardCodeModal(order.id); setCardCode(''); }} className="p-1.5 rounded-lg bg-blue-100 hover:bg-blue-200 transition-colors" title="تسليم الكود">
                                  <CheckCircle className="w-3.5 h-3.5 text-blue-600" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {filteredOrders.length === 0 && (
                    <div className="p-8 text-center text-gray-400">لا توجد طلبات</div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ===== PRODUCTS ===== */}
          {activeTab === 'products' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="flex items-center justify-between">
                <div className="relative flex-1 max-w-xs">
                  <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder="بحث عن منتج..."
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    className="w-full pr-9 pl-4 py-2 bg-white rounded-lg border border-gray-200 text-sm outline-none focus:border-amber-400"
                  />
                </div>
                <button onClick={() => openProductModal()} className="px-4 py-2 bg-amber-500 text-white text-sm font-bold rounded-lg hover:bg-amber-600 flex items-center gap-2">
                  <Plus className="w-4 h-4" /> إضافة منتج
                </button>
              </div>

              <div className="bg-white rounded-xl shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-gray-50 border-b border-gray-100">
                        <th className="text-right px-4 py-3 font-semibold text-gray-600">المنتج</th>
                        <th className="text-right px-4 py-3 font-semibold text-gray-600">الفئة</th>
                        <th className="text-right px-4 py-3 font-semibold text-gray-600">السعر الأصلي</th>
                        <th className="text-right px-4 py-3 font-semibold text-gray-600">سعر البيع</th>
                        <th className="text-right px-4 py-3 font-semibold text-gray-600">الحالة</th>
                        <th className="text-right px-4 py-3 font-semibold text-gray-600">إجراءات</th>
                      </tr>
                    </thead>
                    <tbody>
                      {searchedProducts.map(product => (
                        <tr key={product.id} className="border-b border-gray-50 hover:bg-gray-50/50">
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <span className="text-xl">{product.icon}</span>
                              <div>
                                <p className="font-medium text-gray-800">{product.name}</p>
                                <p className="text-xs text-gray-500 truncate max-w-[200px]">{product.description}</p>
                              </div>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-gray-600">{product.category}</td>
                          <td className="px-4 py-3 text-gray-500">{formatPrice(product.original_price)} د.ج</td>
                          <td className="px-4 py-3 font-bold text-amber-600">{formatPrice(product.sell_price)} د.ج</td>
                          <td className="px-4 py-3">
                            <span className={`text-xs px-2 py-1 rounded-full ${product.is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                              {product.is_active ? 'نشط' : 'معطل'}
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-1">
                              <button onClick={() => openProductModal(product)} className="p-1.5 rounded-lg bg-blue-100 hover:bg-blue-200 transition-colors">
                                <Edit className="w-3.5 h-3.5 text-blue-600" />
                              </button>
                              <button onClick={() => handleDeleteProduct(product.id)} className="p-1.5 rounded-lg bg-red-100 hover:bg-red-200 transition-colors">
                                <Trash2 className="w-3.5 h-3.5 text-red-600" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ===== USERS ===== */}
          {activeTab === 'users' && (
            <div className="bg-white rounded-xl shadow-sm overflow-hidden animate-fadeIn">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-100">
                      <th className="text-right px-4 py-3 font-semibold text-gray-600">المستخدم</th>
                      <th className="text-right px-4 py-3 font-semibold text-gray-600">الهاتف</th>
                      <th className="text-right px-4 py-3 font-semibold text-gray-600">الدور</th>
                      <th className="text-right px-4 py-3 font-semibold text-gray-600">الحالة</th>
                      <th className="text-right px-4 py-3 font-semibold text-gray-600">إجراءات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map(u => (
                      <tr key={u.id} className="border-b border-gray-50 hover:bg-gray-50/50">
                        <td className="px-4 py-3">
                          <div>
                            <p className="font-medium text-gray-800">{u.full_name}</p>
                            <p className="text-xs text-gray-500" dir="ltr">{u.email}</p>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-gray-600" dir="ltr">{u.phone || '-'}</td>
                        <td className="px-4 py-3">
                          <select
                            value={u.role}
                            onChange={e => handleUserRole(u.id, e.target.value)}
                            className="text-xs px-2 py-1 rounded-lg border border-gray-200 bg-white"
                          >
                            <option value="customer">زبون</option>
                            <option value="moderator">مشرف</option>
                            <option value="admin">مدير</option>
                          </select>
                        </td>
                        <td className="px-4 py-3">
                          <span className={`text-xs px-2 py-1 rounded-full ${u.is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                            {u.is_active ? 'نشط' : 'معطل'}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <button
                            onClick={() => handleToggleUser(u.id)}
                            className={`p-1.5 rounded-lg transition-colors ${u.is_active ? 'bg-red-100 hover:bg-red-200' : 'bg-green-100 hover:bg-green-200'}`}
                            title={u.is_active ? 'حظر' : 'تفعيل'}
                          >
                            {u.is_active ? <Ban className="w-3.5 h-3.5 text-red-600" /> : <CheckCircle className="w-3.5 h-3.5 text-green-600" />}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ===== COUPONS ===== */}
          {activeTab === 'coupons' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="flex justify-end">
                <button onClick={() => { setCouponForm({ code: '', discount_type: 'percentage', discount_value: 0, min_order_amount: 0, max_uses: 100, expires_at: '', is_active: true }); setShowCouponModal(true); }} className="px-4 py-2 bg-amber-500 text-white text-sm font-bold rounded-lg hover:bg-amber-600 flex items-center gap-2">
                  <Plus className="w-4 h-4" /> إضافة كوبون
                </button>
              </div>
              <div className="bg-white rounded-xl shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-gray-50 border-b border-gray-100">
                        <th className="text-right px-4 py-3 font-semibold text-gray-600">الكود</th>
                        <th className="text-right px-4 py-3 font-semibold text-gray-600">نوع الخصم</th>
                        <th className="text-right px-4 py-3 font-semibold text-gray-600">القيمة</th>
                        <th className="text-right px-4 py-3 font-semibold text-gray-600">الاستخدام</th>
                        <th className="text-right px-4 py-3 font-semibold text-gray-600">الانتهاء</th>
                        <th className="text-right px-4 py-3 font-semibold text-gray-600">إجراءات</th>
                      </tr>
                    </thead>
                    <tbody>
                      {coupons.map(c => (
                        <tr key={c.id} className="border-b border-gray-50 hover:bg-gray-50/50">
                          <td className="px-4 py-3 font-mono font-bold text-amber-600" dir="ltr">{c.code}</td>
                          <td className="px-4 py-3 text-gray-600">{c.discount_type === 'percentage' ? 'نسبة مئوية' : 'مبلغ ثابت'}</td>
                          <td className="px-4 py-3 font-bold">{c.discount_type === 'percentage' ? `${c.discount_value}%` : `${formatPrice(c.discount_value)} د.ج`}</td>
                          <td className="px-4 py-3 text-gray-600">{c.current_uses}/{c.max_uses || '∞'}</td>
                          <td className="px-4 py-3 text-xs text-gray-500">{c.expires_at ? formatDate(c.expires_at) : 'بدون انتهاء'}</td>
                          <td className="px-4 py-3">
                            <button onClick={() => handleDeleteCoupon(c.id)} className="p-1.5 rounded-lg bg-red-100 hover:bg-red-200 transition-colors">
                              <Trash2 className="w-3.5 h-3.5 text-red-600" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ===== MESSAGES ===== */}
          {activeTab === 'messages' && (
            <div className="space-y-3 animate-fadeIn">
              {messages.length === 0 ? (
                <div className="bg-white rounded-xl shadow-sm p-8 text-center text-gray-400">لا توجد رسائل</div>
              ) : (
                messages.map(msg => (
                  <div key={msg.id} className={`bg-white rounded-xl shadow-sm p-4 transition-all ${!msg.is_read ? 'border-r-4 border-amber-500' : ''}`}>
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="font-bold text-gray-800 text-sm">{msg.name} {!msg.is_read && <span className="text-xs bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full">جديد</span>}</h3>
                        <p className="text-xs text-gray-500" dir="ltr">{msg.email}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-gray-400">{formatDate(msg.created_at)}</span>
                        {!msg.is_read && (
                          <button onClick={() => handleMarkRead(msg.id)} className="p-1 rounded bg-gray-100 hover:bg-gray-200">
                            <Eye className="w-3.5 h-3.5 text-gray-600" />
                          </button>
                        )}
                      </div>
                    </div>
                    {msg.subject && <p className="text-xs font-semibold text-gray-700 mb-1">{msg.subject}</p>}
                    <p className="text-sm text-gray-600">{msg.message}</p>
                  </div>
                ))
              )}
            </div>
          )}

          {/* ===== ANNOUNCEMENTS ===== */}
          {activeTab === 'announcements' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="flex justify-end">
                <button onClick={() => { setAnnouncementForm({ text: '', color: '#ffffff', bg_color: '#F59E0B', is_active: true }); setShowAnnouncementModal(true); }} className="px-4 py-2 bg-amber-500 text-white text-sm font-bold rounded-lg hover:bg-amber-600 flex items-center gap-2">
                  <Plus className="w-4 h-4" /> إضافة إعلان
                </button>
              </div>
              {announcements.map(ann => (
                <div key={ann.id} className="bg-white rounded-xl shadow-sm p-4 flex items-center justify-between">
                  <div className="flex-1">
                    <div className="px-3 py-2 rounded-lg text-sm inline-block mb-1" style={{ backgroundColor: ann.bg_color, color: ann.color }}>
                      {ann.text}
                    </div>
                    <p className="text-xs text-gray-400">{formatDate(ann.created_at)}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => handleToggleAnnouncement(ann.id, ann.is_active)} className={`p-1.5 rounded-lg transition-colors ${ann.is_active ? 'bg-green-100' : 'bg-gray-100'}`}>
                      {ann.is_active ? <CheckCircle className="w-3.5 h-3.5 text-green-600" /> : <XCircle className="w-3.5 h-3.5 text-gray-400" />}
                    </button>
                    <button onClick={() => handleDeleteAnnouncement(ann.id)} className="p-1.5 rounded-lg bg-red-100 hover:bg-red-200">
                      <Trash2 className="w-3.5 h-3.5 text-red-600" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* ===== ACTIVITY LOG ===== */}
          {activeTab === 'activity' && (
            <div className="bg-white rounded-xl shadow-sm overflow-hidden animate-fadeIn">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-100">
                      <th className="text-right px-4 py-3 font-semibold text-gray-600">المستخدم</th>
                      <th className="text-right px-4 py-3 font-semibold text-gray-600">العملية</th>
                      <th className="text-right px-4 py-3 font-semibold text-gray-600">التاريخ</th>
                    </tr>
                  </thead>
                  <tbody>
                    {activityLog.map(log => (
                      <tr key={log.id} className="border-b border-gray-50">
                        <td className="px-4 py-3 text-gray-700">{log.user_name || 'نظام'}</td>
                        <td className="px-4 py-3 text-gray-600">{log.action}</td>
                        <td className="px-4 py-3 text-xs text-gray-400">{formatDate(log.created_at)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {activityLog.length === 0 && <div className="p-8 text-center text-gray-400">لا توجد سجلات بعد</div>}
              </div>
            </div>
          )}

          {/* ===== SETTINGS ===== */}
          {activeTab === 'settings' && (
            <div className="bg-white rounded-xl shadow-sm p-6 animate-fadeIn">
              <h3 className="text-lg font-bold text-gray-800 mb-4">إعدادات الموقع</h3>
              <div className="space-y-4 max-w-lg">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">اسم الموقع</label>
                  <input type="text" value={settingsForm.site_name} onChange={e => setSettingsForm(p => ({ ...p, site_name: e.target.value }))} className="w-full px-4 py-2 bg-gray-50 rounded-lg border border-gray-200 text-sm outline-none focus:border-amber-400" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">وصف الموقع</label>
                  <input type="text" value={settingsForm.site_description} onChange={e => setSettingsForm(p => ({ ...p, site_description: e.target.value }))} className="w-full px-4 py-2 bg-gray-50 rounded-lg border border-gray-200 text-sm outline-none focus:border-amber-400" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">رقم CCP</label>
                  <input type="text" value={settingsForm.ccp_number} onChange={e => setSettingsForm(p => ({ ...p, ccp_number: e.target.value }))} className="w-full px-4 py-2 bg-gray-50 rounded-lg border border-gray-200 text-sm outline-none focus:border-amber-400" dir="ltr" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">رقم RIP</label>
                  <input type="text" value={settingsForm.rip_number} onChange={e => setSettingsForm(p => ({ ...p, rip_number: e.target.value }))} className="w-full px-4 py-2 bg-gray-50 rounded-lg border border-gray-200 text-sm outline-none focus:border-amber-400" dir="ltr" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">اسم صاحب الحساب</label>
                  <input type="text" value={settingsForm.account_name} onChange={e => setSettingsForm(p => ({ ...p, account_name: e.target.value }))} className="w-full px-4 py-2 bg-gray-50 rounded-lg border border-gray-200 text-sm outline-none focus:border-amber-400" />
                </div>
                <button onClick={handleSaveSettings} disabled={settingsSaving} className="px-6 py-2.5 bg-amber-500 text-white font-bold text-sm rounded-lg hover:bg-amber-600 transition-colors disabled:opacity-50">
                  {settingsSaving ? '⏳ جاري الحفظ...' : '💾 حفظ الإعدادات'}
                </button>

                {/* رسالة نتيجة الحفظ */}
                {settingsMsg && (
                  <div className={`rounded-lg p-4 text-sm font-medium animate-fadeIn whitespace-pre-line ${
                    settingsMsg.includes('⚠️') || settingsMsg.includes('❌') ? 'bg-red-50 text-red-700 border border-red-200' :
                    'bg-green-50 text-green-700 border border-green-200'
                  }`}>
                    {settingsMsg}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </main>

      {/* ===== MODALS ===== */}

      {/* Product Modal */}
      {showProductModal && (
        <Modal onClose={() => setShowProductModal(false)} title={editingProduct ? 'تعديل منتج' : 'إضافة منتج'}>
          <div className="space-y-3">
            <InputField label="الأيقونة (Emoji)" value={productForm.icon} onChange={v => setProductForm(p => ({ ...p, icon: v }))} />
            <InputField label="اسم المنتج" value={productForm.name} onChange={v => setProductForm(p => ({ ...p, name: v }))} />
            <InputField label="الوصف" value={productForm.description} onChange={v => setProductForm(p => ({ ...p, description: v }))} />
            
            {/* رابط الصورة */}
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">🖼️ رابط صورة المنتج</label>
              <input
                type="url"
                value={productForm.image_url}
                onChange={e => setProductForm(p => ({ ...p, image_url: e.target.value }))}
                placeholder="https://example.com/image.png"
                dir="ltr"
                className="w-full px-3 py-2 bg-gray-50 rounded-lg border border-gray-200 text-sm outline-none focus:border-amber-400"
              />
              {productForm.image_url && (
                <div className="mt-2 rounded-lg overflow-hidden border border-gray-200 bg-gray-100">
                  <img src={productForm.image_url} alt="معاينة" className="w-full h-32 object-contain" onError={e => (e.currentTarget.style.display = 'none')} />
                </div>
              )}
            </div>
            <div className="grid grid-cols-2 gap-3">
              <InputField label="السعر الأصلي" type="number" value={String(productForm.original_price)} onChange={v => setProductForm(p => ({ ...p, original_price: Number(v) }))} />
              <InputField label="سعر البيع" type="number" value={String(productForm.sell_price)} onChange={v => setProductForm(p => ({ ...p, sell_price: Number(v) }))} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">الفئة</label>
                <select value={productForm.category} onChange={e => setProductForm(p => ({ ...p, category: e.target.value }))} className="w-full px-3 py-2 bg-gray-50 rounded-lg border border-gray-200 text-sm">
                  <option value="google-play">Google Play</option>
                  <option value="netflix">Netflix</option>
                  <option value="playstation">PlayStation</option>
                  <option value="xbox">Xbox</option>
                  <option value="itunes">iTunes</option>
                  <option value="spotify">Spotify</option>
                  <option value="free-fire">Free Fire</option>
                </select>
              </div>
              <InputField label="المخزون" type="number" value={String(productForm.stock)} onChange={v => setProductForm(p => ({ ...p, stock: Number(v) }))} />
            </div>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={productForm.is_active} onChange={e => setProductForm(p => ({ ...p, is_active: e.target.checked }))} className="accent-amber-500" />
              <span className="text-sm text-gray-700">منتج نشط</span>
            </label>
            <button onClick={handleSaveProduct} className="w-full py-2.5 bg-amber-500 text-white font-bold text-sm rounded-lg hover:bg-amber-600">
              {editingProduct ? 'حفظ التعديلات' : 'إضافة المنتج'}
            </button>
          </div>
        </Modal>
      )}

      {/* Coupon Modal */}
      {showCouponModal && (
        <Modal onClose={() => setShowCouponModal(false)} title="إضافة كوبون">
          <div className="space-y-3">
            <InputField label="الكود" value={couponForm.code} onChange={v => setCouponForm(p => ({ ...p, code: v.toUpperCase() }))} dir="ltr" />
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">نوع الخصم</label>
              <select value={couponForm.discount_type} onChange={e => setCouponForm(p => ({ ...p, discount_type: e.target.value as any }))} className="w-full px-3 py-2 bg-gray-50 rounded-lg border border-gray-200 text-sm">
                <option value="percentage">نسبة مئوية (%)</option>
                <option value="fixed">مبلغ ثابت (د.ج)</option>
              </select>
            </div>
            <InputField label="قيمة الخصم" type="number" value={String(couponForm.discount_value)} onChange={v => setCouponForm(p => ({ ...p, discount_value: Number(v) }))} />
            <div className="grid grid-cols-2 gap-3">
              <InputField label="الحد الأدنى للطلب" type="number" value={String(couponForm.min_order_amount)} onChange={v => setCouponForm(p => ({ ...p, min_order_amount: Number(v) }))} />
              <InputField label="الحد الأقصى للاستخدام" type="number" value={String(couponForm.max_uses)} onChange={v => setCouponForm(p => ({ ...p, max_uses: Number(v) }))} />
            </div>
            <InputField label="تاريخ الانتهاء" type="date" value={couponForm.expires_at} onChange={v => setCouponForm(p => ({ ...p, expires_at: v }))} />
            <button onClick={handleSaveCoupon} className="w-full py-2.5 bg-amber-500 text-white font-bold text-sm rounded-lg hover:bg-amber-600">
              إضافة الكوبون
            </button>
          </div>
        </Modal>
      )}

      {/* Announcement Modal */}
      {showAnnouncementModal && (
        <Modal onClose={() => setShowAnnouncementModal(false)} title="إضافة إعلان">
          <div className="space-y-3">
            <InputField label="نص الإعلان" value={announcementForm.text} onChange={v => setAnnouncementForm(p => ({ ...p, text: v }))} />
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">لون النص</label>
                <input type="color" value={announcementForm.color} onChange={e => setAnnouncementForm(p => ({ ...p, color: e.target.value }))} className="w-full h-10 rounded-lg cursor-pointer" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">لون الخلفية</label>
                <input type="color" value={announcementForm.bg_color} onChange={e => setAnnouncementForm(p => ({ ...p, bg_color: e.target.value }))} className="w-full h-10 rounded-lg cursor-pointer" />
              </div>
            </div>
            <button onClick={handleSaveAnnouncement} className="w-full py-2.5 bg-amber-500 text-white font-bold text-sm rounded-lg hover:bg-amber-600">
              إضافة الإعلان
            </button>
          </div>
        </Modal>
      )}

      {/* ═══ نافذة تفاصيل الطلب ═══ */}
      {showOrderDetail && (() => {
        const order = orders.find(o => o.id === showOrderDetail);
        if (!order) return null;
        return (
          <Modal onClose={() => setShowOrderDetail(null)} title={`طلب #${order.id.slice(0, 8)}`}>
            <div className="space-y-3">
              {/* الحالة */}
              <div className={`text-center py-2 rounded-lg text-sm font-bold ${
                order.status === 'pending' ? 'bg-amber-100 text-amber-700' :
                order.status === 'confirmed' ? 'bg-blue-100 text-blue-700' :
                order.status === 'delivered' ? 'bg-green-100 text-green-700' :
                'bg-red-100 text-red-700'
              }`}>
                {STATUS_LABELS[order.status]}
              </div>

              {/* معلومات المنتج */}
              <div className="bg-gray-50 rounded-lg p-3">
                <p className="text-xs text-gray-500 mb-1">المنتج</p>
                <p className="font-bold text-gray-800">{order.product_name}</p>
                <p className="text-sm text-amber-600 font-bold">{formatPrice(order.final_price)} د.ج</p>
              </div>

              {/* معلومات العميل */}
              <div className="bg-gray-50 rounded-lg p-3">
                <p className="text-xs text-gray-500 mb-2">بيانات العميل</p>
                <div className="space-y-1 text-sm">
                  <p><span className="text-gray-500">الاسم:</span> <span className="font-medium">{order.delivery_name}</span></p>
                  <p><span className="text-gray-500">البريد:</span> <span className="font-medium" dir="ltr">{order.delivery_email}</span></p>
                  {order.delivery_phone && <p><span className="text-gray-500">الهاتف:</span> <span className="font-medium" dir="ltr">{order.delivery_phone}</span></p>}
                </div>
              </div>

              {/* كود الخصم */}
              {order.coupon_code && (
                <div className="bg-green-50 rounded-lg p-3">
                  <p className="text-xs text-green-600">كود خصم: <span className="font-bold">{order.coupon_code}</span> (-{formatPrice(order.discount_amount)} د.ج)</p>
                </div>
              )}

              {/* وصل التحويل */}
              {order.receipt_url && (
                <div className="bg-gray-50 rounded-lg p-3">
                  <p className="text-xs text-gray-500 mb-2">وصل التحويل:</p>
                  {order.receipt_url.startsWith('data:') ? (
                    <img src={order.receipt_url} alt="وصل" className="max-h-40 rounded-lg border mx-auto" />
                  ) : (
                    <a href={order.receipt_url} target="_blank" rel="noreferrer" className="text-blue-600 text-sm underline">فتح الوصل ←</a>
                  )}
                </div>
              )}

              {/* كود البطاقة (لو تم التسليم) */}
              {order.card_code && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                  <p className="text-xs text-green-600 mb-1">كود البطاقة:</p>
                  <p className="font-mono text-lg font-bold text-green-800 text-center" dir="ltr">{order.card_code}</p>
                </div>
              )}

              {/* سبب الرفض */}
              {order.notes && order.status === 'rejected' && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                  <p className="text-xs text-red-600 mb-1">سبب الرفض:</p>
                  <p className="text-sm text-red-700">{order.notes}</p>
                </div>
              )}

              {/* التاريخ */}
              <p className="text-xs text-gray-400 text-center">{formatDate(order.created_at)}</p>
            </div>
          </Modal>
        );
      })()}

      {/* Card Code Modal */}
      {showCardCodeModal && (
        <Modal onClose={() => setShowCardCodeModal(null)} title="إدخال كود البطاقة">
          <div className="space-y-4">
            <p className="text-sm text-gray-600">أدخل كود البطاقة الرقمية لتسليمه للزبون:</p>
            <InputField label="كود البطاقة" value={cardCode} onChange={setCardCode} placeholder="XXXX-XXXX-XXXX-XXXX" dir="ltr" />
            <button onClick={() => handleOrderAction(showCardCodeModal, 'deliver')} className="w-full py-2.5 bg-green-500 text-white font-bold text-sm rounded-lg hover:bg-green-600 flex items-center justify-center gap-2">
              <CheckCircle className="w-4 h-4" /> تسليم الكود
            </button>
          </div>
        </Modal>
      )}

      {/* Reject Modal */}
      {showRejectModal && (
        <Modal onClose={() => setShowRejectModal(null)} title="رفض الطلب">
          <div className="space-y-4">
            <p className="text-sm text-gray-700 font-semibold">اختر سبب الرفض (سيظهر للمشتري):</p>

            {/* أسباب الرفض المحددة مسبقاً */}
            <div className="space-y-2">
              {[
                { value: 'receipt_fake', label: '📄 وصل التحويل مزيف أو غير واضح' },
                { value: 'amount_mismatch', label: '💰 المبلغ المحول لا يطابق سعر المنتج' },
                { value: 'account_blocked', label: '🚫 حسابك محظور بسبب نشاط مشبوه' },
                { value: 'product_unavailable', label: '📦 المنتج غير متوفر حالياً - سيتم استرجاع مبلغك' },
                { value: 'wrong_info', label: '📝 بيانات الاستلام غير صحيحة أو غير مكتملة' },
                { value: 'duplicate_order', label: '🔄 هذا طلب مكرر - لديك طلب سابق لنفس المنتج' },
                { value: 'payment_expired', label: '⏰ انتهت صلاحية التحويل - يرجى إعادة الطلب' },
                { value: 'other', label: '❓ سبب آخر' },
              ].map(reason => (
                <label
                  key={reason.value}
                  className={`flex items-center gap-3 p-3 rounded-xl border-2 cursor-pointer transition-all ${
                    rejectReason === reason.value
                      ? 'border-red-400 bg-red-50'
                      : 'border-gray-200 hover:border-gray-300 bg-white'
                  }`}
                >
                  <input
                    type="radio"
                    name="rejectReason"
                    value={reason.value}
                    checked={rejectReason === reason.value}
                    onChange={e => setRejectReason(e.target.value)}
                    className="accent-red-500"
                  />
                  <span className="text-sm text-gray-700">{reason.label}</span>
                </label>
              ))}
            </div>

            {/* سبب مخصص يظهر عند اختيار "سبب آخر" */}
            {rejectReason === 'other' && (
              <textarea
                placeholder="اكتب سبب الرفض هنا..."
                onChange={e => setRejectReason('other:' + e.target.value)}
                className="w-full px-4 py-3 bg-gray-50 rounded-xl border border-gray-200 text-sm resize-none outline-none focus:border-red-400 animate-fadeIn"
                rows={2}
              />
            )}

            {/* زر الرفض */}
            <button
              onClick={() => handleOrderAction(showRejectModal, 'reject')}
              disabled={!rejectReason}
              className="w-full py-3 bg-red-500 text-white font-bold text-sm rounded-xl hover:bg-red-600 disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2 transition-all"
            >
              <XCircle className="w-4 h-4" />
              تأكيد رفض الطلب
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ===== Helper Components =====

function StatCard({ icon: Icon, label, value, color }: { icon: typeof DollarSign; label: string; value: string | number; color: string }) {
  return (
    <div className="bg-white rounded-xl shadow-sm p-4 flex items-center gap-4">
      <div className={`w-12 h-12 ${color} rounded-xl flex items-center justify-center`}>
        <Icon className="w-6 h-6 text-white" />
      </div>
      <div>
        <p className="text-xs text-gray-500 font-medium">{label}</p>
        <p className="text-lg font-black text-gray-800">{value}</p>
      </div>
    </div>
  );
}

function Modal({ children, onClose, title }: { children: React.ReactNode; onClose: () => void; title: string }) {
  return (
    <div className="fixed inset-0 bg-black/50 z-[9999] flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto animate-fadeIn" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-4 border-b border-gray-100">
          <h3 className="font-bold text-gray-800">{title}</h3>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100"><X className="w-4 h-4" /></button>
        </div>
        <div className="p-4">{children}</div>
      </div>
    </div>
  );
}

function InputField({ label, value, onChange, type = 'text', dir, placeholder }: { label: string; value: string; onChange: (v: string) => void; type?: string; dir?: string; placeholder?: string }) {
  return (
    <div>
      <label className="block text-xs font-semibold text-gray-600 mb-1">{label}</label>
      <input
        type={type}
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        dir={dir}
        className="w-full px-3 py-2 bg-gray-50 rounded-lg border border-gray-200 text-sm outline-none focus:border-amber-400"
      />
    </div>
  );
}
