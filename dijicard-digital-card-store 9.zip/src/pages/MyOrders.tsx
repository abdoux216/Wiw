import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { db } from '../lib/database';
import type { Order } from '../types';
import { Package, Clock, CheckCircle, XCircle, Eye, Copy, AlertTriangle } from 'lucide-react';

const STATUS_MAP: Record<string, { label: string; color: string; bgColor: string; icon: typeof Clock }> = {
  pending: { label: 'قيد المراجعة', color: 'text-amber-700', bgColor: 'bg-amber-50 border-amber-200', icon: Clock },
  confirmed: { label: 'تم التأكيد', color: 'text-blue-700', bgColor: 'bg-blue-50 border-blue-200', icon: CheckCircle },
  delivered: { label: 'تم التسليم', color: 'text-green-700', bgColor: 'bg-green-50 border-green-200', icon: CheckCircle },
  rejected: { label: 'مرفوض', color: 'text-red-700', bgColor: 'bg-red-50 border-red-200', icon: XCircle },
};

// أسباب الرفض اللي يعرضها للمشتري
const REJECT_REASONS: Record<string, { title: string; desc: string; icon: string }> = {
  receipt_fake: {
    title: 'وصل التحويل غير صالح',
    desc: 'وصل التحويل المرفق مزيف أو غير واضح. يرجى رفع وصل واضح وصحيح وإعادة الطلب.',
    icon: '📄',
  },
  amount_mismatch: {
    title: 'المبلغ غير مطابق',
    desc: 'المبلغ الذي قمت بتحويله لا يطابق سعر المنتج. تأكد من تحويل المبلغ الصحيح.',
    icon: '💰',
  },
  account_blocked: {
    title: 'الحساب محظور',
    desc: 'تم حظر حسابك بسبب نشاط مشبوه. تواصل مع الدعم لمزيد من المعلومات.',
    icon: '🚫',
  },
  product_unavailable: {
    title: 'المنتج غير متوفر',
    desc: 'عذراً، المنتج غير متوفر حالياً. سيتم استرجاع مبلغك أو يمكنك اختيار منتج آخر.',
    icon: '📦',
  },
  wrong_info: {
    title: 'بيانات غير صحيحة',
    desc: 'بيانات الاستلام التي أدخلتها غير صحيحة أو غير مكتملة. يرجى إعادة الطلب ببيانات صحيحة.',
    icon: '📝',
  },
  duplicate_order: {
    title: 'طلب مكرر',
    desc: 'لديك طلب سابق لنفس المنتج قيد المعالجة. لا داعي لإعادة الطلب.',
    icon: '🔄',
  },
  payment_expired: {
    title: 'انتهت صلاحية التحويل',
    desc: 'مر وقت طويل على التحويل. يرجى إعادة الطلب وتحويل المبلغ من جديد.',
    icon: '⏰',
  },
};

function getRejectionInfo(notes: string): { title: string; desc: string; icon: string } | null {
  if (!notes) return null;
  // لو السبب مخصص (يبدأ بـ "other:")
  if (notes.startsWith('other:')) {
    return { title: 'تم رفض طلبك', desc: notes.replace('other:', '').trim(), icon: '❓' };
  }
  return REJECT_REASONS[notes] || { title: 'تم رفض طلبك', desc: notes, icon: '⚠️' };
}

export default function MyOrders() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { addToast } = useToast();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedOrder, setExpandedOrder] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    db.getUserOrders(user.id).then(setOrders).catch(() => {
      addToast('فشل في تحميل الطلبات', 'error');
    }).finally(() => setLoading(false));
  }, [user]);

  const formatPrice = (price: number) => new Intl.NumberFormat('ar-DZ').format(price);
  const formatDate = (date: string) => new Date(date).toLocaleDateString('ar-DZ', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' });

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code).then(() => {
      addToast('تم نسخ الكود بنجاح!', 'success');
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-10 h-10 border-4 border-amber-500 border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-black text-gray-800">طلباتي</h1>
            <p className="text-sm text-gray-500 mt-1">تابع حالة طلباتك واستلم أكواد البطاقات</p>
          </div>
          <button
            onClick={() => navigate('/')}
            className="px-4 py-2 bg-amber-500 text-white text-sm font-bold rounded-xl hover:bg-amber-600 transition-colors"
          >
            + طلب جديد
          </button>
        </div>

        {orders.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-sm p-12 text-center">
            <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-gray-700 mb-2">لا توجد طلبات بعد</h3>
            <p className="text-gray-500 mb-6">لم تقم بأي طلب بعد. تصفح المنتجات وابدأ الشراء!</p>
            <button
              onClick={() => navigate('/')}
              className="px-6 py-2.5 bg-amber-500 text-white font-bold text-sm rounded-xl hover:bg-amber-600 transition-colors"
            >
              تصفح المنتجات
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {orders.map(order => {
              const status = STATUS_MAP[order.status] || STATUS_MAP.pending;
              const StatusIcon = status.icon;
              const isExpanded = expandedOrder === order.id;

              return (
                <div key={order.id} className="bg-white rounded-2xl shadow-sm overflow-hidden border border-gray-100 animate-fadeIn">
                  {/* Order Header */}
                  <button
                    onClick={() => setExpandedOrder(isExpanded ? null : order.id)}
                    className="w-full p-4 flex items-center gap-4 text-right hover:bg-gray-50/50 transition-colors"
                  >
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center border ${status.bgColor}`}>
                      <StatusIcon className={`w-6 h-6 ${status.color}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-bold text-gray-800 text-sm truncate">{order.product_name || 'منتج'}</h3>
                        <span className={`text-[11px] px-2 py-0.5 rounded-full border ${status.bgColor} ${status.color} font-medium`}>
                          {status.label}
                        </span>
                      </div>
                      <p className="text-xs text-gray-500">{formatDate(order.created_at)}</p>
                    </div>
                    <div className="text-left">
                      <p className="font-black text-amber-600">{formatPrice(order.final_price)} <span className="text-xs">د.ج</span></p>
                    </div>
                    <Eye className={`w-5 h-5 text-gray-400 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                  </button>

                  {/* Expanded Details */}
                  {isExpanded && (
                    <div className="px-4 pb-4 border-t border-gray-100 pt-4 animate-slideDown">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                        <div className="bg-gray-50 rounded-lg p-3">
                          <p className="text-gray-500 text-xs mb-1">اسم الاستلام</p>
                          <p className="font-medium text-gray-800">{order.delivery_name}</p>
                        </div>
                        <div className="bg-gray-50 rounded-lg p-3">
                          <p className="text-gray-500 text-xs mb-1">بريد الاستلام</p>
                          <p className="font-medium text-gray-800" dir="ltr">{order.delivery_email}</p>
                        </div>
                        {order.coupon_code && (
                          <div className="bg-gray-50 rounded-lg p-3">
                            <p className="text-gray-500 text-xs mb-1">كود الخصم</p>
                            <p className="font-medium text-amber-600">{order.coupon_code}</p>
                          </div>
                        )}
                        {order.discount_amount > 0 && (
                          <div className="bg-gray-50 rounded-lg p-3">
                            <p className="text-gray-500 text-xs mb-1">مبلغ الخصم</p>
                            <p className="font-medium text-green-600">-{formatPrice(order.discount_amount)} د.ج</p>
                          </div>
                        )}
                        {/* سبب الرفض - يظهر فقط للطلبات المرفوضة */}
                        {order.status === 'rejected' && order.notes && (() => {
                          const info = getRejectionInfo(order.notes);
                          if (!info) return null;
                          return (
                            <div className="sm:col-span-2 bg-red-50 border border-red-200 rounded-xl p-4 animate-fadeIn">
                              <div className="flex items-start gap-3">
                                <span className="text-2xl">{info.icon}</span>
                                <div className="flex-1">
                                  <div className="flex items-center gap-2 mb-1">
                                    <AlertTriangle className="w-4 h-4 text-red-500" />
                                    <h4 className="font-bold text-red-700 text-sm">{info.title}</h4>
                                  </div>
                                  <p className="text-sm text-red-600 leading-relaxed">{info.desc}</p>
                                  <button
                                    onClick={() => navigate('/contact')}
                                    className="mt-3 text-xs text-red-600 font-semibold hover:text-red-800 underline"
                                  >
                                    تواصل مع الدعم ←
                                  </button>
                                </div>
                              </div>
                            </div>
                          );
                        })()}
                      </div>

                      {/* Card Code (if delivered) */}
                      {order.status === 'delivered' && order.card_code && (
                        <div className="mt-4 bg-green-50 border-2 border-green-200 rounded-xl p-4">
                          <p className="text-sm text-green-700 font-medium mb-2">🎁 كود البطاقة الخاص بك:</p>
                          <div className="flex items-center gap-3">
                            <code className="flex-1 bg-white px-4 py-3 rounded-lg text-center font-mono text-lg font-bold text-gray-800 border border-green-200" dir="ltr">
                              {order.card_code}
                            </code>
                            <button
                              onClick={() => copyCode(order.card_code!)}
                              className="p-3 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
                            >
                              <Copy className="w-5 h-5" />
                            </button>
                          </div>
                        </div>
                      )}

                      {/* Receipt Image */}
                      {order.receipt_url && (
                        <div className="mt-4">
                          <p className="text-xs text-gray-500 mb-2">وصل التحويل:</p>
                          {order.receipt_url.startsWith('data:') ? (
                            <img src={order.receipt_url} alt="وصل" className="max-h-32 rounded-lg border" />
                          ) : (
                            <span className="text-xs text-gray-400">تم رفع الوصل</span>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
