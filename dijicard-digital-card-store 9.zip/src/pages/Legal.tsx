import { useParams, Link } from 'react-router-dom';
import { Shield, ArrowRight } from 'lucide-react';

export default function Legal() {
  const { type } = useParams<{ type: string }>();
  const isPrivacy = type === 'privacy';

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-3xl mx-auto px-4">
        <div className="bg-white rounded-2xl shadow-sm p-6 sm:p-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center">
              <Shield className="w-6 h-6 text-amber-600" />
            </div>
            <div>
              <h1 className="text-xl font-black text-gray-800">
                {isPrivacy ? 'سياسة الخصوصية' : 'اتفاقية الاستخدام'}
              </h1>
              <p className="text-xs text-gray-500">آخر تحديث: {new Date().toLocaleDateString('ar-DZ')}</p>
            </div>
          </div>

          <div className="prose prose-sm max-w-none text-gray-700 leading-relaxed">
            {!isPrivacy ? (
              <>
                <h2 className="text-lg font-bold text-gray-800 mb-3">اتفاقية استخدام موقع ديجي كارد - DIJICARD</h2>
                
                <p className="mb-4">
                  مرحباً بك في متجر ديجي كارد. باستخدامك لهذا الموقع، فإنك توافق على الشروط والأحكام التالية. يرجى قراءتها بعناية قبل إتمام أي عملية شراء.
                </p>

                <h3 className="font-bold text-gray-800 mb-2">1. طبيعة الخدمة</h3>
                <p className="mb-4">
                  ديجي كارد هو متجر إلكتروني لبيع البطاقات الرقمية (Google Play, Netflix, PlayStation, Xbox, iTunes, Spotify وغيرها) بالدينار الجزائري (DZD). جميع الأسعار معروضة بالدينار الجزائري وتشمل أسعار السوق الموازي.
                </p>

                <h3 className="font-bold text-gray-800 mb-2">2. نظام الدفع</h3>
                <p className="mb-4">
                  الدفع يتم حصرياً عبر تطبيق "بريدي موب" (BaridiMob) من خلال تحويل المبلغ إلى حسابنا البريدي. يجب على الزبون رفع صورة وصل التحويل كإثبات للدفع. الطلب لا يُعالج إلا بعد التحقق من صحة الوصل.
                </p>

                <h3 className="font-bold text-gray-800 mb-2">3. التسليم</h3>
                <p className="mb-4">
                  بعد التحقق من صحة الدفع، يتم تسليم الكود الرقمي عبر البريد الإلكتروني أو من خلال صفحة "طلباتي" في حسابك. مدة التسليم عادةً تكون بين دقائق إلى ساعات قليلة حسب الضغط.
                </p>

                <h3 className="font-bold text-gray-800 mb-2">4. مسؤولية المستخدم</h3>
                <p className="mb-4">
                  يتحمل المستخدم المسؤولية الكاملة عن صحة البيانات المُدخلة (الاسم، البريد الإلكتروني، رقم الهاتف). ديجي كارد غير مسؤول عن أي أخطاء ناتجة عن بيانات خاطئة أدخلها المستخدم.
                </p>

                <h3 className="font-bold text-gray-800 mb-2">5. سياسة الاسترجاع</h3>
                <p className="mb-4">
                  لا يمكن استرجاع البطاقات الرقمية بعد تسليم الكود. إذا كان الكود لا يعمل، تواصل معنا خلال 24 ساعة مع لقطة شاشة توضح المشكلة.
                </p>

                <h3 className="font-bold text-gray-800 mb-2">6. التحذير القانوني ⚖️</h3>
                <div className="bg-red-50 border border-red-200 rounded-xl p-4 mb-4">
                  <p className="text-red-700 font-medium mb-2">
                    تحذير صريح وفقاً لقانون العقوبات الجزائري:
                  </p>
                  <p className="text-red-600 text-sm">
                    يُحظر بشكل قاطع أي محاولة احتيال أو تلاعب. جميع المعاملات مسجلة وموثقة بتاريخ كامل وبيانات المستخدم. أي محاولة للاحتيال (مثل رفع وصل مزيف، أو التلاعب بالأسعار) ستعرض صاحبها للمتابعة القانونية وفقاً ل:
                  </p>
                  <ul className="text-red-600 text-sm mt-2 space-y-1">
                    <li>• المادة 372: العقوبات المترتبة على جريمة الاحتيال</li>
                    <li>• المادة 373: ظروف التشديد</li>
                    <li>• المادة 374: محاولة الاحتيال</li>
                    <li>• المادة 375: العقوبات التكميلية</li>
                  </ul>
                </div>

                <h3 className="font-bold text-gray-800 mb-2">7. الخصوصية وحماية البيانات</h3>
                <p className="mb-4">
                  نلتزم بحماية بياناتك الشخصية وفقاً لسياسة الخصوصية الخاصة بنا. كلمات المرور مشفرة ولا يمكن الاطلاع عليها. بيانات الدفع محمية ولا تُشارك مع أي طرف ثالث.
                </p>

                <h3 className="font-bold text-gray-800 mb-2">8. التعديلات</h3>
                <p className="mb-4">
                  يحتفظ ديجي كارد بحق تعديل هذه الاتفاقية في أي وقت. الاستمرار في استخدام الموقع بعد أي تعديل يُعتبر موافقة ضمنية على الشروط الجديدة.
                </p>
              </>
            ) : (
              <>
                <h2 className="text-lg font-bold text-gray-800 mb-3">سياسة الخصوصية - ديجي كارد</h2>
                
                <p className="mb-4">
                  نحن في ديجي كارد نأخذ حماية بياناتك الشخصية على محمل الجد. تشرح هذه السياسة كيفية جمع واستخدام وحماية معلوماتك الشخصية.
                </p>

                <h3 className="font-bold text-gray-800 mb-2">1. البيانات التي نجمعها</h3>
                <p className="mb-4">
                  عند التسجيل أو إتمام طلب، قد نجمع:
                </p>
                <ul className="mb-4 space-y-1">
                  <li>• الاسم الكامل</li>
                  <li>• البريد الإلكتروني</li>
                  <li>• رقم الهاتف</li>
                  <li>• عنوان IP (لأغراض أمنية)</li>
                  <li>• صور أوصال التحويل</li>
                  <li>• سجل الطلبات والمعاملات</li>
                </ul>

                <h3 className="font-bold text-gray-800 mb-2">2. كيف نستخدم بياناتك</h3>
                <p className="mb-4">
                  نستخدم بياناتك لأغراض:
                </p>
                <ul className="mb-4 space-y-1">
                  <li>• معالجة طلباتك وتسليم المنتجات</li>
                  <li>• التواصل معك بخصوص طلباتك</li>
                  <li>• حماية الموقع من الاحتيال</li>
                  <li>• تحسين خدماتنا وتجربتك</li>
                  <li>• الامتثال للمتطلبات القانونية</li>
                </ul>

                <h3 className="font-bold text-gray-800 mb-2">3. حماية البيانات</h3>
                <p className="mb-4">
                  نتخذ إجراءات أمنية صارمة لحماية بياناتك:
                </p>
                <ul className="mb-4 space-y-1">
                  <li>• كلمات المرور مشفرة (Hashed) ولا يمكن قراءتها</li>
                  <li>• اتصال الموقع مشفر (HTTPS/SSL)</li>
                  <li>• قاعدة البيانات محمية بأنظمة أمنية متقدمة</li>
                  <li>• الوصول للبيانات محدود بالإدارة فقط</li>
                </ul>

                <h3 className="font-bold text-gray-800 mb-2">4. مشاركة البيانات</h3>
                <p className="mb-4">
                  لا نشارك بياناتك الشخصية مع أي طرف ثالث إلا في الحالات التالية:
                </p>
                <ul className="mb-4 space-y-1">
                  <li>• بموافقتك الصريحة</li>
                  <li>• بناءً على طلب قضائي أو من السلطات المختصة</li>
                  <li>• لحماية حقوقنا القانونية في حالات الاحتيال</li>
                </ul>

                <h3 className="font-bold text-gray-800 mb-2">5. حقوقك</h3>
                <p className="mb-4">
                  يحق لك:
                </p>
                <ul className="mb-4 space-y-1">
                  <li>• الوصول إلى بياناتك الشخصية</li>
                  <li>• طلب تعديل أو حذف بياناتك</li>
                  <li>• الاعتراض على معالجة بياناتك</li>
                  <li>• تقديم شكوى لدى الجهة المختصة</li>
                </ul>

                <h3 className="font-bold text-gray-800 mb-2">6. التواصل</h3>
                <p>
                  لأي استفسار حول سياسة الخصوصية، يمكنك التواصل معنا عبر صفحة{' '}
                  <Link to="/contact" className="text-amber-600 hover:underline font-semibold">تواصل معنا</Link>.
                </p>
              </>
            )}
          </div>

          <div className="mt-8 pt-6 border-t border-gray-100">
            <Link to="/" className="inline-flex items-center gap-2 text-amber-600 font-semibold hover:text-amber-700 text-sm">
              <ArrowRight className="w-4 h-4" />
              العودة للرئيسية
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
