import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { Mail, Lock, User, Phone, UserPlus, Shield } from 'lucide-react';

export default function Register() {
  const navigate = useNavigate();
  const { register } = useAuth();
  const { addToast } = useToast();
  const [form, setForm] = useState({
    fullName: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    agreeTerms: false,
    agreePrivacy: false,
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (field: string, value: string | boolean) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!form.fullName || !form.email || !form.phone || !form.password) {
      addToast('يرجى ملء جميع الحقول', 'warning');
      return;
    }
    if (form.password.length < 6) {
      addToast('كلمة المرور يجب أن تكون 6 أحرف على الأقل', 'warning');
      return;
    }
    if (form.password !== form.confirmPassword) {
      addToast('كلمتا المرور غير متطابقتين', 'error');
      return;
    }
    if (!form.agreeTerms || !form.agreePrivacy) {
      addToast('يجب الموافقة على الشروط وسياسة الخصوصية', 'warning');
      return;
    }

    setLoading(true);
    try {
      await register(form.email, form.password, form.fullName, form.phone);
      addToast('تم إنشاء حسابك بنجاح! 🎉', 'success');
      navigate('/');
    } catch (err: any) {
      addToast(err.message || 'فشل في إنشاء الحساب', 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-900 via-gray-800 to-amber-900 px-4 py-12">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 right-20 w-72 h-72 bg-amber-400 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-20 w-96 h-96 bg-amber-600 rounded-full blur-3xl" />
      </div>

      <div className="relative w-full max-w-md">
        <div className="bg-white rounded-3xl shadow-2xl p-8 animate-fadeIn">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-amber-400 to-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
              <UserPlus className="w-7 h-7 text-white" />
            </div>
            <h1 className="text-2xl font-black text-gray-800">إنشاء حساب جديد</h1>
            <p className="text-sm text-gray-500 mt-1">أنشئ حسابك وابدأ بشراء البطاقات</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">الاسم الكامل</label>
              <div className="relative">
                <User className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={form.fullName}
                  onChange={e => handleChange('fullName', e.target.value)}
                  placeholder="محمد أحمد"
                  className="w-full pr-11 pl-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-amber-400 focus:ring-2 focus:ring-amber-100 outline-none transition-all text-sm"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">البريد الإلكتروني</label>
              <div className="relative">
                <Mail className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="email"
                  value={form.email}
                  onChange={e => handleChange('email', e.target.value)}
                  placeholder="example@email.com"
                  className="w-full pr-11 pl-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-amber-400 focus:ring-2 focus:ring-amber-100 outline-none transition-all text-sm"
                  dir="ltr"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">رقم الهاتف</label>
              <div className="relative">
                <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="tel"
                  value={form.phone}
                  onChange={e => handleChange('phone', e.target.value)}
                  placeholder="0550000000"
                  className="w-full pr-11 pl-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-amber-400 focus:ring-2 focus:ring-amber-100 outline-none transition-all text-sm"
                  dir="ltr"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">كلمة المرور</label>
              <div className="relative">
                <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="password"
                  value={form.password}
                  onChange={e => handleChange('password', e.target.value)}
                  placeholder="••••••••"
                  className="w-full pr-11 pl-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-amber-400 focus:ring-2 focus:ring-amber-100 outline-none transition-all text-sm"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">تأكيد كلمة المرور</label>
              <div className="relative">
                <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="password"
                  value={form.confirmPassword}
                  onChange={e => handleChange('confirmPassword', e.target.value)}
                  placeholder="••••••••"
                  className="w-full pr-11 pl-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-amber-400 focus:ring-2 focus:ring-amber-100 outline-none transition-all text-sm"
                />
              </div>
            </div>

            {/* Legal Agreements */}
            <div className="space-y-3 pt-2">
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={form.agreeTerms}
                  onChange={e => handleChange('agreeTerms', e.target.checked)}
                  className="mt-1 w-4 h-4 accent-amber-500"
                />
                <span className="text-xs text-gray-600 leading-relaxed">
                  أوافق على{' '}
                  <Link to="/legal/terms" className="text-amber-600 font-semibold hover:underline">اتفاقية الاستخدام</Link>
                  {' '}وأقر بأنني قرأتها وفهمتها بالكامل
                </span>
              </label>
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={form.agreePrivacy}
                  onChange={e => handleChange('agreePrivacy', e.target.checked)}
                  className="mt-1 w-4 h-4 accent-amber-500"
                />
                <span className="text-xs text-gray-600 leading-relaxed">
                  أوافق على{' '}
                  <Link to="/legal/privacy" className="text-amber-600 font-semibold hover:underline">سياسة الخصوصية</Link>
                  {' '}وأوافق على معالجة بياناتي الشخصية
                </span>
              </label>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-gradient-to-l from-amber-500 to-amber-600 text-white font-bold text-sm rounded-xl hover:from-amber-600 hover:to-amber-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-amber-200/50"
            >
              {loading ? 'جاري إنشاء الحساب...' : 'إنشاء الحساب'}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-sm text-gray-500">
              لديك حساب بالفعل؟{' '}
              <Link to="/login" className="text-amber-600 font-semibold hover:text-amber-700">
                سجل دخولك
              </Link>
            </p>
          </div>

          {/* Legal Warning */}
          <div className="mt-6 bg-red-50 rounded-xl p-3 flex items-start gap-2">
            <Shield className="w-4 h-4 text-red-500 mt-0.5 flex-shrink-0" />
            <p className="text-[11px] text-red-600 leading-relaxed">
              تحذير قانوني: بموافقتك على الشروط، فإنك تقر بأن بياناتك صحيحة وأنك توافق على تسجيل جميع معاملاتك. أي احتيال يعرضك للمتابعة وفقاً للمواد 372-375 من قانون العقوبات الجزائري.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
