import { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../lib/database';
import type { Announcement } from '../types';
import { Menu, X, ShoppingCart, User, LogOut, Package, MessageCircle, Home, ChevronLeft } from 'lucide-react';

export default function Layout({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [siteName, setSiteName] = useState('ديجي كارد');

  // ====== ضغط اللوغو 5 مرات خلال 3 ثواني ======
  const secretClicks = useRef<number[]>([]);
  const handleLogoClick = () => {
    const now = Date.now();
    secretClicks.current = secretClicks.current.filter(t => now - t < 3000);
    secretClicks.current.push(now);
    if (secretClicks.current.length >= 5) {
      secretClicks.current = [];
      navigate('/admin-login');
    } else {
      navigate('/');
    }
  };

  useEffect(() => {
    db.getActiveAnnouncements().then(setAnnouncements).catch(() => {});
    db.getSiteConfig().then(c => setSiteName(c.site_name)).catch(() => {});
  }, []);

  const isLoginPage = location.pathname === '/login' || location.pathname === '/register' || location.pathname === '/admin';

  const handleLogout = async () => {
    await logout();
    setUserMenuOpen(false);
    navigate('/');
  };

  const navLinks = [
    { path: '/', label: 'الرئيسية', icon: Home },
    { path: '/my-orders', label: 'طلباتي', icon: Package },
    { path: '/contact', label: 'تواصل معنا', icon: MessageCircle },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Announcement Bar */}
      {announcements.length > 0 && (
        <div className="w-full overflow-hidden">
          {announcements.map(ann => (
            <div
              key={ann.id}
              className="py-2 px-4 text-center text-sm font-semibold animate-pulse-glow"
              style={{ backgroundColor: ann.bg_color, color: ann.color }}
            >
              {ann.text}
            </div>
          ))}
        </div>
      )}

      {/* Navbar */}
      <nav className="bg-white shadow-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo - اضغط 5 مرات سريع للوحة التحكم */}
            <div
              className="flex items-center gap-2 cursor-pointer select-none"
              onClick={handleLogoClick}
            >
              <div className="w-10 h-10 bg-gradient-to-br from-amber-400 to-amber-600 rounded-xl flex items-center justify-center shadow-lg">
                <ShoppingCart className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-gray-800 leading-tight">{siteName}</h1>
                <span className="text-[10px] text-amber-600 font-medium">DIJICARD</span>
              </div>
            </div>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-1">
              {navLinks.map(link => (
                <button
                  key={link.path}
                  onClick={() => navigate(link.path)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 flex items-center gap-2 ${
                    location.pathname === link.path
                      ? 'bg-amber-50 text-amber-700'
                      : 'text-gray-600 hover:bg-gray-50 hover:text-gray-800'
                  }`}
                >
                  <link.icon className="w-4 h-4" />
                  {link.label}
                </button>
              ))}
            </div>

            {/* User Section */}
            <div className="flex items-center gap-3">
              {user ? (
                <div className="relative">
                  <button
                    onClick={() => setUserMenuOpen(!userMenuOpen)}
                    className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <div className="w-8 h-8 bg-amber-100 rounded-full flex items-center justify-center">
                      <User className="w-4 h-4 text-amber-600" />
                    </div>
                    <span className="hidden sm:block text-sm font-medium text-gray-700">
                      {user.full_name}
                    </span>
                    <ChevronLeft className={`w-4 h-4 text-gray-400 transition-transform ${userMenuOpen ? 'rotate-90' : ''}`} />
                  </button>

                  {userMenuOpen && (
                    <>
                      <div className="fixed inset-0 z-40" onClick={() => setUserMenuOpen(false)} />
                      <div className="absolute left-0 top-full mt-2 w-56 bg-white rounded-xl shadow-xl border border-gray-100 py-2 z-50 animate-slideDown">
                        <div className="px-4 py-2 border-b border-gray-100">
                          <p className="text-sm font-semibold text-gray-800">{user.full_name}</p>
                          <p className="text-xs text-gray-500">{user.email}</p>
                        </div>
                        <button
                          onClick={() => { navigate('/my-orders'); setUserMenuOpen(false); }}
                          className="w-full text-right px-4 py-2 text-sm text-gray-600 hover:bg-gray-50 flex items-center gap-2"
                        >
                          <Package className="w-4 h-4" /> طلباتي
                        </button>
                        <button
                          onClick={handleLogout}
                          className="w-full text-right px-4 py-2 text-sm text-red-600 hover:bg-red-50 flex items-center gap-2"
                        >
                          <LogOut className="w-4 h-4" /> تسجيل الخروج
                        </button>
                      </div>
                    </>
                  )}
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => navigate('/login')}
                    className="px-4 py-2 text-sm font-medium text-gray-600 hover:text-gray-800 transition-colors"
                  >
                    دخول
                  </button>
                  <button
                    onClick={() => navigate('/register')}
                    className="px-4 py-2 bg-amber-500 text-white text-sm font-medium rounded-lg hover:bg-amber-600 transition-colors shadow-sm"
                  >
                    تسجيل
                  </button>
                </div>
              )}

              {/* Mobile menu button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="md:hidden p-2 rounded-lg hover:bg-gray-50"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-gray-100 animate-slideDown">
            <div className="px-4 py-3 space-y-1">
              {navLinks.map(link => (
                <button
                  key={link.path}
                  onClick={() => { navigate(link.path); setMobileMenuOpen(false); }}
                  className={`w-full text-right flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                    location.pathname === link.path
                      ? 'bg-amber-50 text-amber-700'
                      : 'text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  <link.icon className="w-5 h-5" />
                  {link.label}
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Main Content */}
      <main className="flex-1">
        {children}
      </main>

      {/* Footer */}
      {!isLoginPage && (
        <footer className="bg-gray-900 text-gray-300 mt-auto">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* About */}
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <div className="w-10 h-10 bg-gradient-to-br from-amber-400 to-amber-600 rounded-xl flex items-center justify-center">
                    <ShoppingCart className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-white font-bold">{siteName}</h3>
                    <span className="text-xs text-amber-400">DIJICARD</span>
                  </div>
                </div>
                <p className="text-sm text-gray-400 leading-relaxed">
                  متجر البطاقات الرقمية الأول في الجزائر. نشتري لك بطاقات Google Play، Netflix، PlayStation وأكثر بأسعار السوق الموازي بالدينار الجزائري.
                </p>
              </div>

              {/* Links */}
              <div>
                <h3 className="text-white font-semibold mb-4">روابط مهمة</h3>
                <div className="space-y-2">
                  <button onClick={() => navigate('/legal/terms')} className="block text-sm text-gray-400 hover:text-amber-400 transition-colors">اتفاقية الاستخدام</button>
                  <button onClick={() => navigate('/legal/privacy')} className="block text-sm text-gray-400 hover:text-amber-400 transition-colors">سياسة الخصوصية</button>
                  <button onClick={() => navigate('/contact')} className="block text-sm text-gray-400 hover:text-amber-400 transition-colors">تواصل معنا</button>
                </div>
              </div>

              {/* Payment Info */}
              <div>
                <h3 className="text-white font-semibold mb-4">طرق الدفع</h3>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-amber-500 rounded-lg flex items-center justify-center">
                      <span className="text-white text-xs font-bold">BP</span>
                    </div>
                    <span className="text-sm text-gray-400">بريدي موب - BaridiMob</span>
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    الدفع يتم عبر تحويل بريدي موب فقط مع رفع وصل التحويل
                  </p>
                </div>
              </div>
            </div>

            <div className="border-t border-gray-800 mt-8 pt-6 text-center">
              <p className="text-xs text-gray-500">
                © {new Date().getFullYear()} {siteName}. جميع الحقوق محفوظة.
              </p>
              <p className="text-xs text-gray-600 mt-1">
                ⚠️ تحذير قانوني: أي محاولة احتيال ستعرضك للمتابعة القانونية وفقاً للمواد 372-375 من قانون العقوبات الجزائري
              </p>
            </div>
          </div>
        </footer>
      )}
    </div>
  );
}
