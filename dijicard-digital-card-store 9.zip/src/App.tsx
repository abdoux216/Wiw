import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { ToastProvider } from './contexts/ToastContext';
import Layout from './components/Layout';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Order from './pages/Order';
import MyOrders from './pages/MyOrders';
import Contact from './pages/Contact';
import Legal from './pages/Legal';
import AdminLogin from './pages/AdminLogin';
import Admin from './pages/Admin';

export default function App() {
  return (
    <HashRouter>
      <ToastProvider>
        <AuthProvider>
          <Routes>
            {/* صفحات عادية */}
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />

            {/* لوحة التحكم */}
            <Route path="/admin-login" element={<AdminLogin />} />
            <Route path="/admin" element={<Admin />} />

            {/* صفحات مع layout */}
            <Route path="/" element={<Layout><Home /></Layout>} />
            <Route path="/order/:productId" element={<Layout><Order /></Layout>} />
            <Route path="/my-orders" element={<Layout><MyOrders /></Layout>} />
            <Route path="/contact" element={<Layout><Contact /></Layout>} />
            <Route path="/legal/:type" element={<Layout><Legal /></Layout>} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </AuthProvider>
      </ToastProvider>
    </HashRouter>
  );
}
