export interface User {
  id: string;
  email: string;
  full_name: string;
  phone: string;
  role: 'customer' | 'admin' | 'moderator';
  permissions: string[];
  is_active: boolean;
  created_at: string;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  category: string;
  original_price: number;
  sell_price: number;
  icon: string;
  image_url: string;
  is_active: boolean;
  stock: number;
  created_at: string;
}

export interface Order {
  id: string;
  user_id: string;
  product_id: string;
  product_name?: string;
  status: 'pending' | 'confirmed' | 'delivered' | 'rejected';
  delivery_name: string;
  delivery_email: string;
  delivery_phone?: string;
  coupon_code?: string;
  discount_amount: number;
  final_price: number;
  payment_ref?: string;
  receipt_url?: string;
  card_code?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface Coupon {
  id: string;
  code: string;
  discount_type: 'percentage' | 'fixed';
  discount_value: number;
  min_order_amount: number;
  max_uses: number | null;
  current_uses: number;
  expires_at: string;
  is_active: boolean;
  created_at: string;
}

export interface CouponUsage {
  id: string;
  coupon_id: string;
  user_id: string;
  order_id: string;
  used_at: string;
}

export interface Message {
  id: string;
  user_id?: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  is_read: boolean;
  created_at: string;
}

export interface Announcement {
  id: string;
  text: string;
  color: string;
  bg_color: string;
  is_active: boolean;
  created_at: string;
}

export interface ActivityLog {
  id: string;
  user_id?: string;
  user_name?: string;
  action: string;
  details: Record<string, unknown>;
  ip_address?: string;
  created_at: string;
}

export interface SiteSetting {
  id: string;
  key: string;
  value: string;
  updated_at: string;
}

export interface LegalConsent {
  id: string;
  user_id: string;
  consent_type: 'terms' | 'privacy';
  ip_address?: string;
  created_at: string;
}

export interface SiteConfig {
  ccp_number: string;
  rip_number: string;
  account_name: string;
  site_name: string;
  site_description: string;
}
