import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { db } from '../lib/database';
import type { User } from '../types';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<User>;
  register: (email: string, password: string, fullName: string, phone: string) => Promise<User>;
  logout: () => Promise<void>;
  isAdmin: boolean;
  refreshUser: () => Promise<void>;
  setAdminSession: (adminUser: User) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);
const ADMIN_KEY = 'diji_admin_session';
const USER_KEY = 'diji_user_session';

function saveLocal(key: string, data: User) {
  try { localStorage.setItem(key, JSON.stringify(data)); } catch {}
}
function loadLocal(key: string): User | null {
  try { const d = localStorage.getItem(key); return d ? JSON.parse(d) : null; } catch { return null; }
}
function removeLocal(key: string) {
  try { localStorage.removeItem(key); } catch {}
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const refreshUser = useCallback(async () => {
    try {
      // 1) جلسة أدمن
      const admin = loadLocal(ADMIN_KEY);
      if (admin && (admin.role === 'admin' || admin.role === 'moderator')) {
        setUser(admin);
        return;
      }

      // 2) جلسة Supabase
      const current = await db.getCurrentUser();
      if (current) {
        setUser(current);
        saveLocal(USER_KEY, current);
        return;
      }

      // 3) احتياطي
      const saved = loadLocal(USER_KEY);
      if (saved && saved.role !== 'admin') {
        setUser(saved);
        return;
      }

      setUser(null);
    } catch {
      const saved = loadLocal(USER_KEY);
      if (saved) { setUser(saved); return; }
      setUser(null);
    }
  }, []);

  useEffect(() => {
    refreshUser().finally(() => setLoading(false));

    const { data: { subscription } } = db.onAuthStateChange((event, sessionUser) => {
      // تجاهل INITIAL_SESSION لأن refreshUser يعالجه
      if (event === 'INITIAL_SESSION') return;

      if (event === 'SIGNED_IN' && sessionUser) {
        db.getOrCreateProfile(
          sessionUser.id, sessionUser.email || '',
          sessionUser.user_metadata?.full_name || sessionUser.email?.split('@')[0] || '',
          sessionUser.user_metadata?.phone || ''
        ).then(profile => {
          setUser(profile);
          saveLocal(USER_KEY, profile);
        }).catch(() => {
          const fallback: User = {
            id: sessionUser.id, email: sessionUser.email || '',
            full_name: sessionUser.user_metadata?.full_name || sessionUser.email?.split('@')[0] || '',
            phone: sessionUser.user_metadata?.phone || '',
            role: 'customer', permissions: [], is_active: true,
            created_at: new Date().toISOString()
          };
          setUser(fallback);
          saveLocal(USER_KEY, fallback);
        });
      }

      if (event === 'SIGNED_OUT') {
        // امسح جلسة الزبون فقط (خلي الأدمن)
        removeLocal(USER_KEY);
        const admin = loadLocal(ADMIN_KEY);
        if (!admin) setUser(null);
      }
    });

    return () => subscription.unsubscribe();
  }, [refreshUser]);

  const login = async (email: string, password: string): Promise<User> => {
    const loggedInUser = await db.login(email, password);
    if (!loggedInUser) throw new Error('فشل في تسجيل الدخول');
    setUser(loggedInUser);
    saveLocal(USER_KEY, loggedInUser);
    try { await db.logActivity(loggedInUser.id, 'تسجيل دخول', { email }); } catch {}
    return loggedInUser;
  };

  const register = async (email: string, password: string, fullName: string, phone: string) => {
    try {
      const newUser = await db.register(email, password, fullName, phone);
      setUser(newUser);
      saveLocal(USER_KEY, newUser);
      try { await db.logActivity(newUser.id, 'تسجيل حساب جديد', { email, fullName }); } catch {}
      return newUser;
    } catch (err: any) {
      if (err.message === 'CONFIRM_EMAIL') throw new Error('تم إنشاء حسابك! ✅\nتحقق من بريدك الإلكتروني واضغط على رابط التأكيد ثم سجل دخولك.');
      throw err;
    }
  };

  const logout = async () => {
    if (user) { try { await db.logActivity(user.id, 'تسجيل خروج'); } catch {} }
    removeLocal(ADMIN_KEY);
    removeLocal(USER_KEY);
    try { await db.logout(); } catch {}
    setUser(null);
  };

  const setAdminSession = async (adminUser: User) => {
    saveLocal(ADMIN_KEY, adminUser);
    setUser(adminUser);
    try { await db.logActivity(adminUser.id, 'دخول لوحة التحكم'); } catch {}
  };

  const isAdmin = user?.role === 'admin' || user?.role === 'moderator';

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, isAdmin, refreshUser, setAdminSession }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
}
